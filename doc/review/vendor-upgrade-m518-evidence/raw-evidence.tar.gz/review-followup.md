# M518 read-only review follow-up

## Verdict

**No new blocking source defect found in the requested follow-up.** The four previous blockers are resolved. This is source/receipt validation, not additional test execution or final compatibility acceptance.

Only Python file reads and this small report write ran. No worker, shell, compiler, tests, index operation, install, cleanup, source/store edit or store open ran. No constants or safety gates changed.

## Repairs and existing test evidence

- Candidate `src/snapshot/mod.rs:220–226` exports `node_properties_merged`, whose non-null columns override row values. Candidate `snapshot_cov_tests.rs:142–159` checks the live and restored column value. Root `vendor_compatibility.rs:136–187` still requires `title="current"`, current edge text, weight `0.25` and semantic re-export equality. The loss assertions were not weakened. The intentional upstream row-first expectation was replaced with the reviewed column-first contract.
- `snapshot_identity.rs:436–458` checks collisions using `str::trim` and nonempty aliases, then serializes the original declaration unchanged. The refusal test at `:857–867` covers both declaration orders.
- `vendor_compatibility.rs:96–101` now calls `DirectGraphStore::vector_search_direct`; `:339–344` unwraps GraphView and checks CSR edge count and weight. Both former compile defects are gone.
- The added real restore fixture (`vendor_compatibility.rs:191–325`) asserts all four catalog declaration types, the named vector binding, rebuilt vector search, usable hierarchy, explicit Sum=10/Count=5 rollups and semantic identity equality. This is more than an empty-catalog identity roundtrip.

Raw logs, not only JSON summaries, contain **152 storage passes (108 unit + 44 integration, including all five compatibility tests), 10 checkpoint passes, and 39 + 21 PPR/embedding passes; zero failures**. All receipt summary lines occur in those logs. The total is 222, not 222 vendor-native tests. Checkpoint filtering of 857 other tests remains explicit.

All root/vendor source and lock hashes in `verified-consumer-source-binding.json` match current bytes. File-read Git HEAD resolution matches the recorded root, Samyama and RuVector pins. The five-file patch is 99,580 bytes, SHA256 `23deec4f7d25c16379f4f0e4a5fc73534e22a8a8a538a3f6751561b6db3c3a9e`; tracked and audit copies match. The historical three-file patch remains present with its old hash. `patch-recreation-check.json` records native apply-check exit 0 and exact candidate-diff equality; this reviewer did not rerun that command.

## Prepared ledger probe

**No blocking proof-scope or old-expiry defect found, provided the documented copy sequence is followed.** Adapter/probe/old-lock/new-lock bytes match the preparation receipt.

- Both manifests compile the actual adapter via `#[path]`, with old Samyama 1.7.0/HNSW 0.2.1 versus new 1.11.0/HNSW 0.3.5. Both lock chrono 0.4.39 and librocksdb-sys 8.10.0. This is the current adapter across vendor generations, not every historical adapter or database schema.
- Expected specs come from explicit inputs; records come from old-generation transition results; event sequences are captured from the old-generation reader. Comparing these frozen old observations against the new reader is a valid **compatibility** oracle. It is not an independent oracle for lifecycle/event correctness: a shared adapter bug can exist in both generations. Do not expand the claim beyond this boundary.
- The `"cancelled"` profile actually yields **CancelRequested**, not terminal Cancelled. The plan and project review correctly name cancel-requested.
- Reading old records does not validate their lease against the current clock. Mutation reclaims with the same owner, obtains a fresh epoch/expiry and rejects the old fence before completing. Therefore a long delay between old creation and new verification does not itself break the probe.
- Creation and fresh-fence completion still use the unchanged 30-second wall-clock lease. They are not clock-independent: a process suspension or clock jump during that active interval can cause a runtime refusal. Run those short active sections without a long hold; do not describe a future pass as deterministic clock testing.
- `verify` opens writable RocksDB even without ledger transitions; it is a logical-read probe, not a read-only disk open. `path.is_dir()` does not enforce provenance. The runner must use only closed, disposable copies: old baseline copy, new verification copy and separate new mutation copy. Keep the old original closed, hash it before/after, and never give the new writable copy back to the old engine. The recorded operation sequence does this. No such run has happened yet.

This remains String-only JSON ledger compatibility. It proves neither generic PropertyValue bincode migration/downgrade, arbitrary existing stores, WAL replay nor crash durability.

## Status and remaining limits

`remaining-native-verification-plan.json`, `verification-progress.json`, `data/vendor_sources.yaml` and `doc/review/vendor-upgrade-m518.md` do not overclaim completed runtime gates. Native HNSW **0.3.4** vector compilation is paused without a result; consumer **0.3.5** results remain distinct. Ledger builds/store runs, native snapshot/WCC/vector units, broader consumers, critic, clippy, final architecture/graph review and GSD closeout remain pending.

The critic command explicitly excludes both real GGUF model tests, regardless of local model presence. Non-model passes cannot establish Candle/FlatGraph inference equivalence.

The records acknowledge the first build's 15 GiB-floor breach and subsequent 20 GiB soft-pause/2-second monitoring; they do not claim the floor held throughout. The parent's latest approximately 17 GiB observation is not a resource-clearance conclusion from this review. Original-tree and frozen-M517 preservation are retained claims, not newly re-audited here. Assumptions: bound source bytes remain unchanged; the future runner uses the stated old generator, closed-copy provenance and immutable expected baseline. Import/deploy/promotion/graph-write locks remain closed.
