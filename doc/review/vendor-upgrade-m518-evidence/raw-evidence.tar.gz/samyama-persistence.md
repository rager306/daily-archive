# Samyama persistence / `.sgsnap` upgrade audit (source only)

## Scope and evidence

- Local committed vendor: `fd45131b3e1d3e58e8a6ff1ee7618d872477e79d` (L).
- Common upstream base: `4ede0b428ca5dfcffdb3a827fc913afca2f020b8`.
- Target exact `origin/main`: `17e55660ef90bc177ac9b55a1a22a9d39b41aa0f` (U).
- Latest semver tag: `v1.11.0`, `4c99eb364fc919366e60b268b611390518b63566` (R).
- Vendor source references below are `git show U:path` unless marked L. No upstream claim uses the dirty worktree. Current daily-archive files were read directly.
- No cargo, tests, builds, benchmarks, live-store open, fetch, checkout, merge, reset, clean, or push occurred. Test names below are available source, **not passing results**.
- GitNexus was consulted first. The vendor index is still at the common base and its query was partial. The daily-archive index is one commit behind with FTS disabled; `ParseJobLedger` was absent. Exact pinned files / current files are therefore the evidence, not stale graph results.
- Dirty vendor files in this scope include graph Node/Edge/PropertyValue, persistence storage/manager/WAL, snapshot format/import/export, SDK embedded, and main. A direct Python read confirms its `PropertyValue` still has the old order; its RocksDB decode still uses unversioned bincode and its WAL still has the old XOR envelope. This is not a clean L build and must be preserved as a separate baseline when reproducing the upgrade.

## Decision in brief

**Do not open an existing general-purpose RocksDB directory in U/R in place.** `PropertyValue` binary discriminants changed with no storage-version field or legacy PropertyMap decoder. A compatibility error is not guaranteed: some old values can decode as wrong new values. Upgrade through a validated export from the old writer into a new, isolated store, or add an explicit old-wire decoder/versioned storage migration before any deployment. Keep a byte-preserving rollback copy; downgrading after new writes is not safe.

`.sgsnap` is a different format: gzip JSON-lines with header `version: 2`, accepting versions 1 and 2. The `kg-snapshots-v9` / `kg-snapshots-v10` artifact tags, and Samyama software releases `v1.10.0` / `v1.11.0`, are **not** `.sgsnap` format numbers. The importer gates `header.format` and `header.version`, not artifact filenames or `samyama_version`. Newer snapshots can load in an older reader but lose semantics without a version rejection.

ADR-040 remains binding: Samyama is the sole KG/vector/persistence store; use its isolated-copy tests rather than introducing another DB. No import permission, constants, configuration, or repositories were changed.

## 1. Binary wire layout: concrete upgrade / downgrade blocker

### Layouts and serialization sites

`Node` keeps the same derived serde fields/order in L/U (`src/graph/node.rs:52-71`): `id, version, labels, properties, created_at, updated_at`. `Edge` likewise (`src/graph/edge.rs:63-85`): `id, version, source, target, edge_type, properties, created_at`. NodeId/EdgeId/Label/EdgeType serde wrappers are unchanged (`src/graph/types.rs:39-40,65-66,92-93,125-126`). The MVCC implementation changed, not these struct field lists.

RocksDB does **not** serialize Node/Edge directly. Both L/U use identical derived `StoredNode` and `StoredEdge` field lists, with a nested `properties: Vec<u8>` (`src/persistence/storage.rs:68-87`). The inner bytes are `bincode::serialize(&node.properties)` / `edge.properties` and decode straight into the **current** PropertyMap (`U storage.rs:199-222,238-252,293-317,333-346,447-461,479-492`; L equivalents `162-185,199-213,222-246,260-274,329-343,361-375`). No generation field or fallback decoder is present on these read paths.

Bincode remains `1.3`; RocksDB remains crate `0.22`, librocksdb-sys `0.16.0+8.10.0` (`L Cargo.toml:45-46`, `U Cargo.toml:69-70`; `L Cargo.lock:1739-1742`, `U Cargo.lock:2437-2440`). This is **not** a detected RocksDB native-engine version upgrade. Four CFs remain `default,nodes,edges,indices` with LZ4 and PointInTime physical-WAL recovery (`U storage.rs:132-157`; L `105-130`). The incompatible part is Samyama's value encoding inside otherwise unchanged KV rows.

| Bincode enum ordinal | L PropertyValue | U/R PropertyValue |
|---:|---|---|
| 0 | String(String) | same |
| 1 | Integer(i64) | same |
| 2 | Float(f64) | same |
| 3 | Boolean(bool) | same |
| 4 | DateTime(i64) | same, labeled legacy |
| 5 | Array(Vec<PropertyValue>) | Date(i32) |
| 6 | Map(HashMap<String, PropertyValue>) | LocalTime(i64) |
| 7 | Vector(Vec<f32>) | Time { nanos:i64, offset_seconds:i32 } |
| 8 | Duration { months:i64, days:i64, seconds:i64, nanos:i32 } | LocalDateTime { secs:i64, nanos:u32 } |
| 9 | Null | ZonedDateTime { secs:i64, nanos:u32, offset_seconds:i32, zone:Option<String> } |
| 10–14 | no variants | Array, Map, Vector, Duration, Null |

References: `L src/graph/property.rs:81-99`; `U:81-135`. Introducing commit: `6a0cb5c2f3f54405fd89d60dc55bb7da9c43078b` (#689/#768). Keeping DateTime at slot 4 protects DateTime itself, **not** every variant that followed it. Nested arrays/maps multiply the exposure.

The installed source for the lockfile's bincode 1.3.3 confirms fixed-width enum indexes (`.../bincode-1.3.3/src/ser/mod.rs:206-226`) and public `deserialize` uses `allow_trailing_bytes` (`src/lib.rs:177-184`). Source-derived example, **not executed**: an old one-property map holding an empty `Map` encodes ordinal 6 plus a zero u64 map length; U can read that as `LocalTime(0)` rather than reject it. A final old empty Array at ordinal 5 can read as Date(0), with unused bytes accepted. New Array/Map/Vector/Duration/Null ordinals 10–14 are unknown to L. Do not make recovery-on-error the only compatibility check.

### Value is not another serialized disk enum

The query `Value` enum is `#[derive(Debug, Clone)]`, **not Serialize/Deserialize**, in both versions. L `src/query/executor/record.rs:73-92`: Node, NodeRef, Edge, EdgeRef, Property, Path, Null. U `112-153`: Node and Edge now hold `Box`, and List / Map were added before Null. These changes matter for Rust API/exhaustive matching, not an on-disk bincode Value discriminant. The persisted enum here is PropertyValue; `.sgsnap` separately uses explicit JSON property tags.

### Startup is not fail-closed everywhere

`PersistenceManager::recover` propagates the row decode failure (`src/persistence/mod.rs:643-662`). The upstream server catches initialization/recovery errors, prints them and can continue with empty/partial graph rather than refusing startup (`src/main.rs:1921-1955,1987-2026`). A wrong-value decode will not even print an error. Validate semantic inventory independently before serving; do not infer a healthy recovery from a running process or counts alone.

## 2. Actual `.sgsnap` format and asymmetric compatibility

- L `src/snapshot/format.rs:23-26`, U `69-72`: `SNAPSHOT_VERSION = 2`.
- U `src/snapshot/mod.rs:741-761`: only format `sgsnap`, versions 1/2 accepted; `samyama_version` is not checked. File/tag names do not govern compatibility.
- L records: header, nodes, edges. U adds header `dropped`, optional `queries`, `read_only`, optional `results`, node timestamps, hierarchy `t:h`, index catalog `t:i` (`format.rs:12-53,76-113,160-197`). These remain format 2; missing fields have defaults, unknown record types are skipped (`mod.rs:1073-1135`).
- U exports `t:i` **even when empty** (`mod.rs:185-195`). U restores exact declarations, preserving names/dimensions/metric/quantization, with a conflict count when target definitions win (`1245-1295`). An absent catalog (legacy file) is deliberately different from an explicit empty catalog (`format.rs:175-197,229-242`).
- U/R plain snapshots preserve legacy `DateTime`, `Vector`, `Duration`, Array, Map tags (`mod.rs:1327-1492`). This avoids the binary discriminant problem and makes old-writer → new-reader snapshot migration the safer route, subject to semantic checks.
- New `Date`, `LocalTime`, `Time`, `LocalDateTime`, `ZonedDateTime` have explicit `__type` JSON tags (`1338-1358`). L's importer recognizes only DateTime/Vector/Duration and falls back to Map (`L mod.rs:598-646`). Thus U → L **loads without a format bump but changes temporal types into Maps**. If those maps are re-exported, new software may re-recognize the tag, but old queries already observed the wrong type.
- L also ignores `t:i`/`t:h` and node timestamp keys. A downgrade can silently remove unique constraints, fulltext/vector configuration, hierarchy declarations, and timestamps; older HTTP vector rediscovery replaces missing declarations with its inferred default behavior.
- U/R import remaps IDs and **appends/merges into a target**, not replace it (`mod.rs:360-372,763,1036-1065,1083-1114`). `import_snapshot` over an existing graph is not a full rollback. Restore into a fresh store or explicitly clear an isolated failed store, with an independently recorded node/edge identity mapping. A fresh import is also not a promise that original numeric IDs survive sparse/deleted IDs.
- Old v2 snapshots lacked node timestamps. U imports these as zeros, not fabricated creation times (`mod.rs:977-988`). U carries node timestamps, still drops edge creation timestamps (`format.rs:103-113`, `mod.rs:338-357`). Node/edge MVCC history/version chains are not carried in the snapshot records; RocksDB recovery resets row versions to 1 (`storage.rs:243-251,338-346`). Do not equate `.sgsnap` with a temporal/history backup.
- Both readers trim string properties (`L mod.rs:583`; U `1393`), and non-finite JSON floats are not a full-fidelity transport. These are existing limitations, not introduced upgrade drift. Include whitespace and typed values in regression fixtures rather than trusting record counts.
- U fixes old empty-label/multilabel import faults (`mod.rs:830-845,962-975` versus L `319-323,390-396`). It fixes deleted frozen edges being exported (`U:128-141,279-300`) and failed-import partial state, including dedup additions (`689-721`). These are upgrade benefits, not evidence that all migration cases pass.

Relevant commits: `c3c78b97620f5da031cf94896ceb34a0938c46e0` (node timestamps); `f45d870ee1c9a3656e0b2eac0e852cc1361a516e` (label roundtrip); `d2d1325ea69bfa848da813398ea87b7e7a0e6f18` (deleted edges); `cda5ad4bdf92486888930018fcc3da61824b7b2e` (import rollback); `ac9ea67628ebcdd9b7a127752c9ab8161c090bef` (snapshot index catalog); `72264681bceb2200dec7fece83e172a8172de0b1` (dedup merge refusal rollback); `9f1ae29b485127321c935ecff9890e6205c4a5bb` (loss report).

R → U in this scope changes only `src/snapshot/format.rs` / `mod.rs`: merge-shape reporting and warnings from `d2f2618dc64cc1b4707c9515df17300fd41020ae` (#1847). No new serialized header/node/edge/property format was added by that diff. R already has the binary incompatibility and additive snapshot features above. U's >20% merge warning is not a refusal; do not use free-text names/symbols as scientific-entity dedup keys merely because merge counts rise (`mod.rs:1146-1192`).


### Critical DA fingerprint incompatibility despite unchanged header 2

U/R export **always** writes an index-catalog line (`t:i`), including an empty catalog, then optional hierarchy declarations (`t:h`) (`src/snapshot/mod.rs:185-213`). Current daily-archive `fingerprint_snapshot` dispatches only `n` and `e` and rejects every other record type with `SnapshotIdentityError::UnsupportedRecord` (`crates/kg-storage/src/snapshot_identity.rs:170-194`). Therefore even an empty-index new snapshot is rejected by this identity validator; the upstream importer accepting additive records does not make the full daily-archive snapshot path compatible. This is an integration blocker, not merely lost metadata on downgrade.

Before adoption, update the identity validator **in a separately authorized implementation** to explicitly handle supported index/hierarchy declaration types and define whether/how they belong in the semantic fingerprint. Do not blindly ignore all unknown records: names/metric/dimensions/unique constraints change graph behavior. Test both catalog-bearing new exports and catalog-absent legacy files while preserving the existing fingerprint contract. No repository edit was made by this audit.

## 3. WAL, durability, storage manager, and rollback

### Logical WAL upgrade is readable forward, not backward

L `src/persistence/wal.rs:124-155,213-233,273-285`: length-prefixed unversioned bincode WalRecord; checksum is XOR, not CRC32. U `115-165` keeps WalEntry order (CreateNode/CreateEdge/DeleteNode/DeleteEdge/UpdateNodeProperties/UpdateEdgeProperties/Checkpoint) and field order. Serialized properties remain opaque Vec<u8> containing PropertyMap bytes.

U writes top-bit-set length frames `0x80000000 | body_len`; body is format-byte 1, sequence u64 LE, bincode(entry), IEEE CRC-32 (`wal.rs:167-243,328-361`). It explicitly decodes old top-bit-clear XOR frames. This protects the outer legacy WAL envelope, **not** old nested PropertyValue interpretation in a future consumer. Commit `d7abf913acf1a2ff12c4b79e7815ffdc894a5a3a` (#1547).

L does not mask the length's high bit (`L wal.rs:273-277`), so replaying a new short record can attempt a buffer allocation exceeding 2 GiB before EOF/error. Do not feed new/mixed WAL files into an old Wal::replay. U WalError::Corruption reports a byte offset, not L's sequence. Source comments and an old parser are not sufficient to downgrade an operational/audit WAL.

U stops replay cleanly at a torn body and errors on checksum corruption (`wal.rs:394-460`; `fe187c4ccb6a977f7b33f5bfcc0f5ab3cbfcbc68`). Filename-based sequence initialization still reads segment names, not final record sequence (`519-541`). After restart, append sequence monotonicity is not established by the claimed counter; checkpoint retention/rotation remains TODO (`478-499`). Keep this as an audit/CDC caveat, not an extra reason to invent recovery outside Samyama.

### Recovery source and durability semantics

Both L and U `PersistenceManager::recover` scan RocksDB; neither replays the logical WAL. U makes that explicit (`mod.rs:11-29,643-662`, ADR-023 amendment; `1cf3f4608559cf14dd3bbb9e8e6702c361d1621a`). `PersistenceManager::new` makes `data/`, `wal/`, `vectors/` and opens writable RocksDB (`87-119`): even “just open to inspect” is not a read-only operation.

`SAMYAMA_FSYNC=1|true|yes|on` now enables RocksDB WriteOptions sync and logical-WAL sync_data at construction. Default stays off (`storage.rs:103-123,161-167`; `wal.rs:279-294,350-362`; `b6797e92e658b07e9dfb766b3caac62613cedcee`). A normal WAL flush alone is not fsync (`wal.rs:369-374`); `checkpoint` flushes storage and appends a WAL marker (`mod.rs:731-756`). No audit configuration was changed. Later isolated runs must record the chosen durability mode explicitly.

U adds mutation-journal persistence (`mod.rs:374-568`) instead of inferring writes from returned query records (`79e05f26fa0b34df910e72ae5652126de8e4c9f0`), and merges node row/column properties before encoding (`498-512`; `56e22432605fb9629908e10a124bd59b8ab6ba27`, `d28b395ad06fa60dded3614cc36c2a1b96beed65`). Direct `persist_create_node` / `storage.put_node` still serialize exactly the provided row map and require the caller to materialize columns (`mod.rs:216-228`; `storage.rs:191-204`). API changes do not automatically repair custom persistence wiring.

U's previously-empty `indices` CF now holds bincode index catalogs, absent key defaulting empty (`storage.rs:392-435`; `53ab9c85cd8559fac7d85f5a661d07580b79c96a`). `recover_into` loads rows then builds declarations (`mod.rs:665-727`). L ignores those declarations; downgrade loses uniqueness enforcement as well as query indexes. U reports failed restoration instead of ensuring every definition rebuilt (`src/index/catalog.rs:83-93`, `src/graph/store.rs:6463-6535`); inspect `failed`, not just row count.

The new `src/migrate` module is a Neo4j APOC JSON importer (`src/migrate/mod.rs:1-9`, `neo4j_json.rs:133`), **not** a legacy Samyama RocksDB/bincode upgrader (`295aaea12271842dcd6cb03516c3cb54e0719225`). No legacy binary-store conversion is provided on the audited load paths.

### Server snapshot persistence caveats (separate from DA embedded path)

`persist_snapshot` improves atomic replacement: preserve old marker/file until rename, fsync tmp/marker and containing directory (`src/snapshot/persist.rs:25-68`; `94291ae81320514f198898fff809675892b71ebf`). Available test covers a failed replacement preserving the last snapshot; do not downgrade back to L's marker-first-removal implementation.

However current U HTTP import persists **the incoming bytes**, not a new export of the full accumulated graph, to one `snapshots/default.sgsnap`, and logs persist failure while returning successful import (`src/http/handler.rs:3008-3011,3043-3055`). Source-derived hazards to test on disposable copies:

1. Import snapshot A, then B into the same graph: memory has A+B, disk holds only B; restart without RocksDB rows restores only B.
2. Import snapshot, then change one node through regular persistence: any recovered RocksDB tenant sets `recovered=true`; startup skips the bulk snapshot altogether (`src/main.rs:1934-1955,2015-2026`). Rows not individually persisted may disappear.
3. Encrypted HTTP import is accepted and raw encrypted bytes persisted (`handler.rs:3025-3055`), but startup `restore_persisted_snapshots` calls the **plain gzip** importer, with no key (`persist.rs:74-91`). An encrypted persisted snapshot can fail to restore. DA's current adapter/SDK import likewise calls plain import, not maybe-encrypted.
4. Successful memory import with disk persist error is not a durable acknowledgment (`handler.rs:3054,3073-3098`). These are source findings, not exercised failures.

## 4. Current daily-archive and latest SDK semantics

### Scientific graph vs real RocksDB consumer

- Binding ADR: `doc/adr/ADR-040-technology-stack-lock-samyama-ruvector-rvf.md`, §0/§11.6/§11.8: Samyama sole engine, snapshot before destructive migration, import gate remains false. The ADR's “full rollback” description must not be assumed to mean append-import replaces an existing graph.
- Current `crates/kg-storage/src/samyama_adapter.rs:28-48` owns GraphStore + QueryEngine, not PersistenceManager. `open_for_mode` refuses a disk-path env (`61-79`); `graph_mode.rs:12-15,117-128` specifically says RocksDB is not wired for this scientific CLI graph. The KG path is in-memory and explicit `.sgsnap` export/import (`adapter.rs:357-369`).
- Exception: operational `SamyamaJobLedger`, label `ParseJobLedger`, is a **real** PersistenceManager-backed RocksDB consumer (`crates/da-adapters/src/parse_job_ledger.rs:17-31,44-70`). Do not report “daily-archive has no disk persistence.”
- Ledger state/events/spec are all JSON embedded in PropertyValue::String (`ledger.rs:155-163,227-245`). String ordinal 0 and StoredNode field layout are unchanged, so this subset is **not directly hit** by shifted array/vector/null ordinals. This is a source inference, not verified cross-version reopen; unknown other rows remain unsafe.
- Ledger recover reads RocksDB (`59`), reads exact state rows (`95-109`), and writes WAL update → storage.put_node → checkpoint (`173-188`). The update persistence method itself still only appends logical WAL (`U mod.rs:581-596`); ledger's explicit put_node is load-bearing. Keep that in the upgrade.
- New ledger writes create new-format WAL; rollback does not replay that log today, but an old offline WAL reader is unsafe. Checkpoint + default unsynced behavior is not proof of per-ack power-loss safety. Do not use general `.sgsnap` ID-remapping to restore the operational ledger without verifying job-ID ↔ node-ID semantics and its isolated tenant.

### Rust EmbeddedClient does not auto-load or auto-save

Latest Rust SDK `crates/samyama-sdk/src/embedded.rs`:

```rust
pub fn new() -> Self;                                        // :28, fresh in-memory store
pub fn with_store(store: Arc<RwLock<GraphStore>>) -> Self;   // :36
pub fn persistence_manager(&self, base_path: impl AsRef<Path>)
    -> Result<PersistenceManager, PersistenceError>;        // :79-84, constructs a separate manager
pub async fn export_snapshot(&self, _tenant: &str, path: &Path)
    -> Result<ExportStats, Box<dyn Error>>;                  // :97-107
pub async fn import_snapshot(&self, _tenant: &str, path: &Path)
    -> Result<ImportStats, Box<dyn Error>>;                  // :110-120
pub async fn import_snapshot_dedup(&self, _tenant: &str, path: &Path, dedup_keys: &[&str])
    -> Result<ImportStats, Box<dyn Error>>;                  // :127-138
```

Creating a persistence_manager does **not** attach it to the client, recover its rows, persist later query writes, or auto-save on drop. Query writes only call QueryEngine (`:369-381`), delete_graph clears only memory (`:391-395`). Snapshot export uses direct File::create + BufWriter and no atomic temp/rename/marker/fsync sequence (`:102-106`); caller must implement safe publication if this is the backup boundary. `_tenant` is ignored and export header tenant is hardcoded default (`src/snapshot/mod.rs:169`). Latest Python embedded construction similarly wraps `EmbeddedClient::new` (`sdk/python/src/lib.rs:254`); it does not turn this into auto-loading persistence.

Vector file data is a separate, apparently stable layout: StoredVector { node_id:u64, vector:Vec<f32> } (`src/vector/index.rs:219-224`), bincode Vec<StoredVector> dump/load (`560-605`). hnsw_rs changed 0.2.1 → 0.3.4 (`348de70e8befa5441aefd04c95a0f4ff46f63316`), but these files rebuild HNSW from vectors, not deserialize a raw hnsw_rs structure. New fp16 dump rounds into the same f32 disk format; `VectorIndexManager::load_all` uses the unquantized loader (`manager.rs:410-491`), losing runtime fp16 choice/name unless rebuilt through the newer index catalog. Catalog-based restore and ad-hoc vector checkpoint restore are not interchangeable. Do not claim ANN results identical without deterministic fixture/metric comparison.

## 5. Available regression evidence and proposed isolated-copy commands

**None was run.** Commands below are a later, explicitly authorized regression plan, only after making disposable old/new source copies plus stopped/checkpoint-consistent DB copies. Use separate targets and explicit paths. Do not run in the dirty vendor tree, against `data/samyama`, or against a live ledger. Do not use a workspace-wide cargo command. Preserve current dirty overlay in its own old baseline; a clean L copy alone does not represent all current code.

### First add cross-generation fixture coverage (missing evidence)

Existing temporal tests are JSON/snapshot roundtrips, not proof of old bincode DB compatibility: `tests/temporal_representation.rs:27-29` uses serde_json; `snapshot::temporal_tests::a_pre_689_snapshot_still_loads` tests the DateTime JSON tag only (`src/snapshot/mod.rs:2681-2686`). WAL legacy fixtures use current WalEntry with properties bytes, not old-generation PropertyValue decoding (`tests/wal_checksum.rs:146-189`).

Before opening real copies, implement a small **fixture-only** harness in the isolated repositories, run old writer and new reader as separate binaries:

1. Old writer produces exactly one String/Integer/Float/Bool/DateTime/Array/Map/Vector/Duration/Null node property and edge property per fixture, plus nested combinations, sparse IDs, multi-label and unlabeled nodes, deleted frozen edges. Record a canonical typed semantic manifest independent of the encoder.
2. Old writer writes an isolated RocksDB directory, `.sgsnap`, vector files and WAL; close before byte-preserving copy. New reader compares variant identity and full values, not just success/counts. This should expose binary ordinal drift; recovery-error assertions alone miss wrong-value decodes.
3. Test new-writer → old-reader on separate copies too. Refuse production downgrade for unsupported temporals/indexes. Do **not** directly run old WAL replay on unrestricted new frames; bound the process for the >2-GiB allocation hazard.
4. For supported `.sgsnap` transport, import into a **fresh** new store with no dedup. Rebuild/check index definitions and graph task results; verify drop/loss inventory, whitespace, typed properties, labels and stable VIDs. Do not compare snapshot bytes: headers/timestamps/hash-set order are not canonical.
5. Stop old and new fixture processes and prove old rollback copy reopens unchanged. Never switch an upgraded writable DB path back to the old engine.
6. Ledger fixture: submit/claim/checkpoint/events with old isolated daily-archive binary; reopen copied directory with the new adapter and verify job record/spec/fence/cursor/events; reopen a separate original copy with old binary. Use only String subset fixtures unless testing explicit non-String rejection.

### Existing focused upstream commands (source-backed)

Set the working directory to an authorized disposable U copy and `CARGO_TARGET_DIR` to its separate scratch target. Preserve/use its own native Cargo environment, the confirmed RocksDB 8.10 ABI config, and deterministic inputs. Do not run these now:

```text
cargo test -p samyama --test snapshot_preserves_properties
cargo test -p samyama --test snapshot_timestamps
cargo test -p samyama --test snapshot_keeps_an_unlabelled_node_unlabelled
cargo test -p samyama --test snapshot_skips_deleted_edges
cargo test -p samyama --test snapshot_import_rollback
cargo test -p samyama --test snapshot_index_catalog
cargo test -p samyama --test snapshot_loss_report
cargo test -p samyama --test snapshot_persistence
cargo test -p samyama --lib snapshot::persist::tests::a_failed_persist_keeps_the_last_good_snapshot
cargo test -p samyama --test write_durability
cargo test -p samyama --test index_definitions_survive_restart
cargo test -p samyama --test recovery_reads_rocksdb_alone
cargo test -p samyama --test wal_checksum
cargo test -p samyama --test wal_torn_tail
cargo test -p samyama --test durability_is_a_choice
cargo test -p samyama --test persist_failure_is_reported
cargo test -p samyama --test snapshot_encryption_round_trip
cargo test -p samyama --lib snapshot::temporal_tests
```

Representative source tests: `write_durability::an_imported_node_keeps_the_properties_a_later_write_did_not_touch` (:195), `index_definitions_survive_restart::a_unique_constraint_still_refuses_a_duplicate_after_a_restart` (:270), `snapshot_index_catalog::a_snapshot_without_a_catalog_still_imports` (:187), `snapshot_index_catalog::the_http_import_of_an_old_snapshot_still_rediscovers_vectors` (:305), `wal_checksum::a_wal_written_in_the_old_format_still_replays_and_takes_new_records` (:171), `recovery_reads_rocksdb_alone::a_restart_with_the_logical_wal_deleted_loses_nothing` (:89). Test existence is not proof of cross-version behavior or coverage of the server hazards above.

### Daily-archive integration on an isolated source copy

Rebind absolute Samyama path dependencies (`Cargo.toml:64-66`) **only in the disposable copy**, otherwise a copied daily-archive still builds the dirty live vendor. Preserve native project config; do not alter the current repository.

```text
cargo test -p kg-storage --features samyama --test contract_samyama
cargo test -p da-adapters --test parse_job_ledger_test
cargo test -p kg-storage --lib graph_mode
```

Available DA tests: `contract_samyama::inner::samyama_passes_export_import_round_trip` and `samyama_passes_graph_store_contract`; `parse_job_ledger_test::durable_ack_reopens_and_events_are_preserved` (:22), `reclaim_fences_stale_worker_and_terminal_state_survives_reopen` (:64); mode refusal test `graph_mode::tests::refuse_persistence_path_nonempty_errors` (:224). They exercise a single linked generation; add old→new→old copied fixture handoff to close the upgrade gap.

## Recommendations / unproven assumptions

1. Keep U as the exact candidate pin, record R separately, and preserve L plus the current dirty overlay. Do not silently replace local vector patches `78b79a62107f3201f24bf30183216e61199e481a` / `fd45131b3e1d3e58e8a6ff1ee7618d872477e79d` during upgrade.
2. Block in-place general RocksDB upgrade/downgrade until there is explicit property-wire migration or cross-version typed fixture evidence. Prefer old-reader `.sgsnap` export into fresh candidate stores for the scientific KG, with known snapshot losses tracked.
3. Treat String-only job-ledger binary compatibility as a limited source inference. Verify copied ledger reopen/ownership/fence semantics independently, and keep rollback copy/WAL generation recorded.
4. Do not enable new temporal property writes, encrypted persistence, generalized dedup, or automatic SDK persistence as part of a dependency bump. Each needs explicit adoption and regression evidence. Current DA plain snapshot import does not gain encryption support merely by linking U.
5. Make startup compatibility validation fail closed before exposing the server; verify missing index/constraint reports and semantic queries. Test server A+B imports, snapshot+post-import write restart, encrypted restart, disk-failed import ack.
6. Existing ADR-040 backup requirements remain; format version 2 or a `kg-snapshots-v10` tag alone is not evidence that a rollback is lossless.

No measured performance, build success, test pass, live-store inventory, or user import permission is asserted.
