# M518 independent source-only correctness review

## Verdict

**Request changes.** Two correctness issues and two integration-test compile defects block the current compatibility gate. None of the tests below was executed by this reviewer.

The review was strictly sequential and read-only for repository/vendor sources and stores. No worker, Cargo/compiler, index rebuild, installation, formatter, source edit, live graph/ledger operation, cleanup or promotion ran. Only this report is written. Existing GitNexus context reads were bound to the exact registered root/candidate paths; lower-bound graph results were not read as proof of absence.

Reviewed: the four scoped root files, three patched Samyama files, upstream snapshot/catalog/getter support code, the requested implementation/fixture/lock receipts, `data/vendor_sources.yaml`, and `doc/review/vendor-upgrade-m518.md`.

## Required changes

### 1. Node reads and snapshot export disagree on the authoritative property value

**High — blocks the new restore contract.**

- Root getter: `crates/kg-storage/src/samyama_adapter.rs:91–98` delegates to the column-first `node_property`.
- Candidate `/root/vendor-source/samyama-graph-m518-17e55660/src/snapshot/mod.rs:220–231` inserts row-map values first and skips a column value when the row already contains that key.
- Candidate `src/graph/store.rs:2162–2167` confirms `set_column_property` does not remove or update the row value.
- New `crates/kg-storage/tests/vendor_compatibility.rs:121–124` creates row `title="stale"` and column `title="current"`. The live getter returns `"current"`, but export serializes `"stale"`. Restore therefore cannot satisfy the `"current"` assertion at **lines 166–171**. Semantic re-export equality alone would still pass for the wrong restored value.

This exporter behavior is inherited, not introduced by the patch. The candidate even has `src/snapshot/snapshot_cov_tests.rs:142–155` explicitly asserting row-first export. It nevertheless blocks the newly promised column-first read/restore contract. Decide and implement one authoritative precedence before accepting M518; a narrow exporter fix can use the existing column-first merged node-property view. Such a change needs its own pre-edit impact warning and patch/receipt update, including the conflicting upstream test. Do not claim the current source passes this roundtrip or weaken the loss-detection assertion silently.

### 2. Vector declaration collision validation misses names that collide after trimming

**High — violates the fail-closed declaration contract.**

- `crates/kg-storage/src/snapshot_identity.rs:436–441` inserts the **raw** `Option<String>` name into `vector_names`.
- Candidate `src/vector/manager.rs:62–70` trims every nonempty name before inserting it into the manager's name map.
- Candidate `src/snapshot/mod.rs:1253–1264` checks incoming definitions against the target's pre-import definitions, not against normalized names of definitions accepted from this file. Candidate `src/graph/store.rs:6503–6509` then passes these names to the manager.

A catalog containing vector name `"a"` on `Paper.v` and name `" a "` on `Entity.v` is accepted by the fingerprint validator but both restore to alias `"a"`; the last declaration wins. Reversing the definitions produces the same sorted semantic identity but a different named-index binding.

Keep the original declared name in the hashed payload, as required. For collision validation only, compare the nonempty names using the pinned manager's trim rule and reject this alias collision. Add both orderings as refusal cases to `duplicate_and_conflicting_declarations_fail_closed` (`snapshot_identity.rs:837–865`). This is collision validation, not substitution of importer-effective metadata into the identity.

### 3. The concrete vector-search assertion compares incompatible ID types

**Medium — prevents integration-test compilation with feature `samyama`.**

At `crates/kg-storage/tests/vendor_compatibility.rs:96–101`, the concrete `SamyamaGraphStore` method call resolves to the inherent `vector_search_direct`, which returns `Vec<(NodeId, f32)>` (`samyama_adapter.rs:162–173`). `node` came from `DirectGraphStore::create_node` and is a `u64` (`traits.rs:70`). `NodeId` has derived same-type equality only; there is no `PartialEq<u64>` (`candidate src/graph/types.rs:38–62`). Thus `assert_eq!(hits[0].0, node)` at **line 101** cannot type-check.

Use `DirectGraphStore::vector_search_direct(&store, ...)` to exercise the port and return `u64`, or explicitly compare the typed ID. The generic shared contract at lines 9–63 is unaffected because its receiver is generic and calls the trait.

### 4. The weighted GraphView test neither unwraps the Result nor uses an available count API

**Medium — prevents integration-test compilation with features `samyama,algorithms`.**

At `crates/kg-storage/tests/vendor_compatibility.rs:202–206`, `graph_view_from(...).await` remains `Result<GraphView, AdapterError>` (`crates/kg-storage/src/adapter.rs:39–46`). Lines **205–206** call a method/access a field on that Result.

After unwrapping, **`edge_count()` still does not exist** on the pinned `GraphView` (`candidate crates/samyama-graph-algorithms/src/common.rs:11–130`; graph lookup found no such symbol, confirmed from the full source). Unwrap the projection and assert the existing CSR edge count, e.g. `view.out_targets.len()`, together with the weight assertion. Do not add production code just to satisfy this test.

## Tests still required before compatibility acceptance

The fixes above need source-specific regressions. The existing tests also need actual execution; library checks do not compile/run the added integration target or vendor unit tests.

- Compile/run `vendor_compatibility` with **both** `samyama,algorithms`; an empty default-feature target is not evidence.
- Run the candidate vector index/manager units, including both F32/F16, conflict and dimension-before-mutation refusal, missing-node/index replacement, backend IDs/counts, exact buckets, dump/reload and >128-vector replacement.
- Run candidate WCC tests for outgoing-only, incoming-only, mixed arrays and isolated nodes, comparing canonical partitions rather than numeric roots.
- Run storage identity units and domain checkpoint units. Preserve fixed v1 digest vectors and exact v1/v2 allowlist/D127 behavior.
- Add/run one real candidate export→fingerprint→fresh-import fixture with **nonempty catalog definitions** and a hierarchy, then inspect restored declarations. The new adapter roundtrip currently exercises only the empty catalog (`vendor_compatibility.rs:152–154`); raw independent wire fixtures establish canonicalization, not agreement with the vendor's emitted/restored declarations. Keep declaration identity separate from successful hierarchy/index rebuild assurance, and do not replace declared defaults with importer fallback values.
- The cross-generation copied ledger reopen, root SONA/RVF/WASM checks, and standalone deterministic critic checks (excluding unauthorized GGUF inference) remain pending gates documented by the parent. No source-only result can substitute for these checks. General legacy PropertyValue bincode upgrade/downgrade remains forbidden.

## What the source review supports

- Vector add validates dimensions before duplicate checks; equal re-add does not mutate; conflicting add errors. Replacement validates dimension/presence first and builds a fresh backend, stored entries and exact buckets before assigning `*self` (`candidate index.rs:376–459`). The manager retains the same per-index Arc, name/model bindings and F32 defaults (`manager.rs:92–100,224–241`). Stored-rounded-bit F16 equality is explicit and tested in source; no f32-identity promise is inferred.
- WCC unions both successor/predecessor arrays (`candidate community.rs:64–70`) and its new source tests use canonical partitions.
- No-declaration fingerprint payload and helpers retain legacy v1 behavior. Any catalog presence, including empty, or hierarchy selects v2; null versus empty catalog is bound (`snapshot_identity.rs:371–389`). Typed declaration fields/defaults and exact metric/quantization variants match the pinned vendor wire definitions. Unknown declarations/fields/types, exact duplicates, raw-name/key collisions and unknown format versions refuse; normalized name collision remains finding 2.
- Domain validation admits only exact v1/v2 strings (`corpus_checkpoint.rs:61–69`). `SnapshotIdentityEvidence::seal/validate` still binds the report digest and refuses `import_eligible=true` (`:140–172`).
- Adapter edge getters are column-first. New temporal JSON carries each numeric/zone component, and query List/Map conversion recurses. Old DateTime/vector/duration/entity-placeholder output is unchanged; placeholders are not lossless entities.
- Known event/readback add-error swallowing, Mock overwrite/dimension/score gaps and nominal-but-unimplemented vendor distance metrics are not newly claimed fixed and are outside this review's required changes.

## Pin, byte and lock corroboration

Read-only native Git confirmed:

- Root HEAD: `eda16b4a496d8c177d2d6b1ab57e5feccf52a4cd`.
- Samyama candidate HEAD: `17e55660ef90bc177ac9b55a1a22a9d39b41aa0f`.
- RuVector candidate HEAD: `bfb257ab9e08db006e9f4c656580bf1190a5d6f9`.

The snapshot-identity, domain-checkpoint and three patched vendor source hashes match their implementation receipts. Adapter/test hashes were recorded independently during this review. Tracked and temporary Samyama patch bytes both hash to `e19e9cf7d35595c468d4974d949c8fe63c4268936e659a17572d073a7a9f0643`.

Python byte checks confirmed the independent canonical literal digests and the fixed legacy gzip bytes/decompression. These are fixture/receipt checks, **not execution of the Rust implementation**.

Parsed consuming locks match the recorded SHA256 values (`809f3d...` root, `50d118...` critic). Critic registry entries are exactly equal before/after; its path versions are ruvllm 2.5.0/core 2.4.0. Root records chrono 0.4.39, Arrow 53.4.1, registry HNSW 0.3.5, crc32fast 1.5.2, libredox 0.1.19, RocksDB 0.22/librocksdb-sys 0.16+8.10 and zstd-sys 2.0.13+zstd1.5.6. No new source-level version mismatch was found within the requested pin/lock contract. Native Rust 1.99 is the reported checked environment; declared Rust 1.85 compatibility is not proven and must not be advertised.

Parent receipts record successful library checks for kg-storage `samyama,algorithms` and da-cli/da-mcp. This reviewer did not rerun them. `doc/review/vendor-upgrade-m518.md:3` and `data/vendor_sources.yaml:4–5` still say compilation is pending; update that status after fixes/results, without implying tests passed.

## Resource and proof boundary

This review changed no constants or safety gates. Assumptions: the reviewed checkout/hash set remains unchanged after handoff; restoration assertions target a fresh disposable store; declared metadata identity does not imply effective rebuild success.

Free space was **20.819 GiB** at the first review inspection and **19.621 GiB** at the post-report inspection; both exceed the 15 GiB floor. These are observations, not a forecast for test linking or permission to clean shared caches. The foreign law-nexus compiler/test hold remains the parent's scheduling gate. No test, cleanup or compiler operation was started here.

Replacement temporarily holds old and rebuilt indexes; its reinsertions also perform linear duplicate-ID scans. Source inspection cannot certify large-index cost, peak memory, native test linking, MSRV, durability, scientific-quality gains or deployment readiness. No promotion/import/deploy/graph-write lock was opened.
