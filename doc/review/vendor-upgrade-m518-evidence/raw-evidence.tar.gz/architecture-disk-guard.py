class UpgradeArchitectureDiskGuard518(UpgradeDiskGuard518):
    def __init__(self, *args, **kwargs):
        self.lease_pause_deferrals=[]
        super().__init__(*args, **kwargs)
    def _check(self):
        if self.closed:return
        free=shutil.disk_usage(self.path).free/2**30
        if self.handle.poll() is None and free < self.pause_gib:
            rows=self.process_rows()
            descendants={self.handle.pid} if self.handle.pid in rows else set()
            for _ in range(len(rows)):
                new={pid for pid,row in rows.items() if row['ppid'] in descendants}-descendants
                if not new:break
                descendants.update(new)
            active_lease=[pid for pid in descendants if rows[pid]['state']!='Z' and 'target/' in rows[pid]['command'] and ('parse_job_ledger_test-' in rows[pid]['command'] or 'm518-ledger-' in rows[pid]['command'])]
            if active_lease:
                self.samples+=1
                self.minimum_gib=min(self.minimum_gib,free)
                self.lease_pause_deferrals.append({'free_gib':free,'pids':active_lease,'time':dt518.datetime.now(dt518.timezone.utc).isoformat(),'reason':'do not SIGSTOP active unchanged30s ledger lease'})
                self.timer=asyncio.get_running_loop().call_later(self.interval_seconds,self._check)
                return
        super()._check()
    def status(self):
        return super().status()|{'active_lease_pause_deferrals':self.lease_pause_deferrals}
