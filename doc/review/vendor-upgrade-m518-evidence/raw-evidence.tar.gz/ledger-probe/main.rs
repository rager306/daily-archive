use da_domain::ContentDigest;
use da_domain::parse_job::{JobEvent, JobLedgerError, JobRecord, JobSpec, JobStatus};
use da_ports::JobLedger;
use serde::{Deserialize, Serialize};
use std::path::Path;

#[path = "/root/daily-archive/crates/da-adapters/src/parse_job_ledger.rs"]
mod actual_ledger;
use actual_ledger::SamyamaJobLedger;

#[derive(Debug, Serialize, Deserialize)]
struct Expected {
    spec: JobSpec,
    record: JobRecord,
    events: Vec<JobEvent>,
}

fn spec(profile: &str) -> JobSpec {
    let mut spec = JobSpec {
        key: ContentDigest::of_text("placeholder"),
        content: vec!["paper-a".into(), "paper-b".into()],
        backend: "grobid".into(),
        projector: "native-v1".into(),
        profile: profile.into(),
        tuning: vec![("window".into(), "2".into())],
        locations: vec!["relative/source".into()],
    };
    spec.key = spec.identity_key().unwrap();
    spec
}

async fn create(path: &Path, expected: &Path) {
    assert!(!path.exists(), "writer only opens a new disposable path");
    let ledger = SamyamaJobLedger::open(path).unwrap();
    let mut records = Vec::new();
    for profile in ["running", "succeeded", "cancelled", "failed"] {
        let spec = spec(profile);
        let first = ledger.submit(spec.clone()).await.unwrap();
        assert_eq!(ledger.submit(spec.clone()).await.unwrap(), first);
        let claimed = ledger
            .claim(&first.job_id, "compatibility-fixture")
            .await
            .unwrap();
        let checkpointed = ledger
            .checkpoint(&first.job_id, &claimed.attempt.clone().unwrap(), 7)
            .await
            .unwrap();
        let record = match profile {
            "running" => checkpointed,
            "succeeded" => ledger
                .complete(
                    &first.job_id,
                    &checkpointed.attempt.clone().unwrap(),
                    ContentDigest::of_text("result"),
                )
                .await
                .unwrap(),
            "cancelled" => ledger.cancel(&first.job_id).await.unwrap(),
            "failed" => ledger
                .fail(
                    &first.job_id,
                    &checkpointed.attempt.clone().unwrap(),
                    "fixture failure".into(),
                )
                .await
                .unwrap(),
            _ => unreachable!(),
        };
        let events = ledger.events(&first.job_id).await.unwrap();
        records.push(Expected {
            spec,
            record,
            events,
        });
    }
    drop(ledger);
    std::fs::write(expected, serde_json::to_vec_pretty(&records).unwrap()).unwrap();
    println!(
        "{}",
        serde_json::json!({"action":"create", "vendor":samyama::VERSION, "jobs":records.len()})
    );
}

async fn verify(path: &Path, expected: &Path, mutate: bool) {
    assert!(
        path.is_dir(),
        "reader must open a copied disposable fixture"
    );
    let expected: Vec<Expected> =
        serde_json::from_slice(&std::fs::read(expected).unwrap()).unwrap();
    let ledger = SamyamaJobLedger::open(path).unwrap();
    assert!(matches!(
        SamyamaJobLedger::open(path),
        Err(JobLedgerError::OwnerBusy)
    ));
    for item in &expected {
        assert_eq!(ledger.spec(&item.record.job_id).await.unwrap(), item.spec);
        assert_eq!(ledger.get(&item.record.job_id).await.unwrap(), item.record);
        assert_eq!(
            ledger.events(&item.record.job_id).await.unwrap(),
            item.events
        );
        assert_eq!(ledger.submit(item.spec.clone()).await.unwrap(), item.record);
        let mut conflict = item.spec.clone();
        conflict.profile.push_str("-conflict");
        assert!(matches!(
            ledger.submit(conflict).await,
            Err(JobLedgerError::Conflict)
        ));
    }
    if mutate {
        let running = expected
            .iter()
            .find(|item| item.record.status == JobStatus::Running)
            .unwrap();
        let old_fence = running.record.attempt.clone().unwrap();
        let reclaimed = ledger
            .claim(&running.record.job_id, "compatibility-fixture")
            .await
            .unwrap();
        assert!(reclaimed.attempt.as_ref().unwrap().epoch > old_fence.epoch);
        assert!(matches!(
            ledger
                .checkpoint(&running.record.job_id, &old_fence, 8)
                .await,
            Err(JobLedgerError::StaleFence { .. })
        ));
        let done = ledger
            .complete(
                &running.record.job_id,
                &reclaimed.attempt.clone().unwrap(),
                ContentDigest::of_text("upgraded result"),
            )
            .await
            .unwrap();
        let events = ledger.events(&running.record.job_id).await.unwrap();
        drop(ledger);
        let reopened = SamyamaJobLedger::open(path).unwrap();
        assert_eq!(reopened.get(&running.record.job_id).await.unwrap(), done);
        assert_eq!(
            reopened.events(&running.record.job_id).await.unwrap(),
            events
        );
        assert_eq!(
            reopened.spec(&running.record.job_id).await.unwrap(),
            running.spec
        );
    }
    println!(
        "{}",
        serde_json::json!({"action":if mutate {"verify-mutate-reopen"} else {"verify"}, "vendor":samyama::VERSION, "jobs":expected.len()})
    );
}

#[tokio::main(flavor = "current_thread")]
async fn main() {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(
        args.len(),
        4,
        "create|verify|verify-mutate copied-store expected.json"
    );
    match args[1].as_str() {
        "create" => create(Path::new(&args[2]), Path::new(&args[3])).await,
        "verify" => verify(Path::new(&args[2]), Path::new(&args[3]), false).await,
        "verify-mutate" => verify(Path::new(&args[2]), Path::new(&args[3]), true).await,
        _ => panic!("unsupported action"),
    }
}
