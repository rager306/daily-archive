# RuVector upstream audit — read-only, before update/build

Audited: 2026-10-13T16:26:36.564146+00:00. Repository: `/root/vendor-source/ruvector`.

## Decision

A **fast-forward to exact upstream `bfb257ab9e08db006e9f4c656580bf1190a5d6f9` is available**: no local-only commits and no tracked patches. Root daily-archive's actual locked RuVector consumers are a **source/API/features/dependency-requirement no-op**, not just manifest-equal. The standalone `tools/learning-critic-ruvllm` is **not** a no-op: `ruvllm` 2.3.0→2.5.0, `ruvector-core` 2.3.0→2.4.0, changed Candle inference and HNSW behavior, and two lock entries require refresh. Source inspection found no removed API used by either consumer. This is not compile/runtime proof.

No checkout, merge, reset, source edits, build, cargo command, clean, install, inference, graph write, runtime/data write, or promotion occurred. Only fetches changed `.git` metadata. Artifacts are outside both working trees, under `/tmp/vendor-upgrade-audit/`.

## Exact revisions and history

| Identity | SHA / result |
|---|---|
| Current checkout `main` | `c6bb23c842d7c220e06e6141d5e55ae52077fe12` (2026-08-23) |
| Origin default branch | `refs/heads/main` |
| Fresh default HEAD / origin/main | `bfb257ab9e08db006e9f4c656580bf1190a5d6f9` (2026-10-13 13:12:05Z) |
| Latest tag by creation and latest non-prerelease release | `ruvector-wasm-v2.3.1` → `06c23951b15d33ef89d38dd1203fb48d5326c403`, published 2026-10-06 03:13:48Z |
| Latest broad crates release | `crates-2026-09-26` → `425d5ca9d289e615a69b4643cfc11df3f93dc06d`, published 2026-09-27 00:37:33Z |
| Full-history merge-base | `c6bb23c842d7c220e06e6141d5e55ae52077fe12` |
| Full-history divergence | **0 ahead / 286 behind** |
| Local-only commits / tracked patches | none / none |
| Untracked, preserved | `.bg-shell/`, `.codebase-memory/`, `.gsd/` |

Latest release is a **WASM-binding release**, not a common Rust workspace version. Root metadata remains version 2.3.0; selected packages use explicit versions. Do not confuse tag labels with actual manifest versions.

The initial checkout was shallow: roots `c6bb23c842d7c220e06e6141d5e55ae52077fe12` and `d061d23020f30be2781229619e66854e7a9391c2`. Initial `status` incorrectly appeared 1 ahead / 50 behind. Fresh `git fetch origin --tags` updated origin to the exact SHA above but still appeared 1/65 and returned no merge-base. GitHub exact-SHA compare already identified current HEAD as the ancestor, 286 commits behind. With parent's explicit authorization, `git fetch origin --unshallow --tags` completed (rc=0); `rev-parse --is-shallow-repository` is now false and local `rev-list` confirms 0/286. **The apparent local bot commit was an artifact of the shallow boundary, not a patch to preserve.** GitHub compare's commit listing was capped at 250, so it was not used as the full commit list.

Full tree comparison: 1,575 changed paths. Exact current/upstream tree listings and reviewed diffs are in adjacent artifacts; no path selection relies on a 50-commit stale audit.

## All direct declarations and actual use

Root `Cargo.toml` declares sona, gnn-rerank, hybrid, agent-memory, solver (default-features=false), rvf-runtime and rvf-types. Direct member declarations also matter:

- `crates/da-application/Cargo.toml`: `ruvector-sona` workspace dependency, default serde-support.
- `crates/da-adapters/Cargo.toml`: direct `ruvector-cognitive-container` absolute path dependency, default features empty.
- `crates/da-mcp/Cargo.toml`: direct `ruvector-hybrid` absolute path dependency.
- `crates/kg-embeddings/Cargo.toml`: direct hybrid + optional workspace solver, default-features=false; `ppr` enables solver/forward-push.
- `crates/kg-algorithms/Cargo.toml`: optional workspace solver, default-features=false; `ppr` enables solver + forward-push and Samyama algorithms.
- `tools/learning-critic-ruvllm/Cargo.toml`: independent workspace; direct `ruvllm` absolute path, **default-features=false, features=[candle, async-runtime]**.

Root lock resolves sona/hybrid/solver/cognitive-container only. Critic lock additionally resolves ruvllm/core/turboquant/sona. gnn-rerank/agent-memory/rvf-types/rvf-runtime have **no member dependency, source import or entry in either consuming lock**; they are declarations, not runtime blast radius. `kg-embeddings::RuVectorBridge` implements local RRF itself; its active vendor API use is feature-gated solver/PPR. Actual vendor hybrid index use is `da-mcp/src/hybrid.rs`.

| Crate | Current → upstream version | Current consumer | Changed tracked files |
|---|---|---|---|
| `ruvector-sona` | `0.2.1` → `0.2.1` | root | 0 |
| `ruvector-hybrid` | `0.1.0` → `0.1.0` | root | 0 |
| `ruvector-solver` | `2.3.0` → `2.3.0` | root | 0 |
| `ruvector-cognitive-container` | `2.3.0` → `2.3.0` | root | 0 |
| `ruvector-gnn-rerank` | `2.3.0` → `2.3.0` | declaration only; no consuming lock entry | 0 |
| `ruvector-agent-memory` | `0.1.0` → `0.1.0` | declaration only; no consuming lock entry | 13 |
| `rvf-types` | `0.2.1` → `0.2.2` | declaration only; no consuming lock entry | 1 |
| `rvf-runtime` | `0.3.2` → `0.3.2` | declaration only; no consuming lock entry | 1 |
| `ruvllm` | `2.3.0` → `2.5.0` | critic only | 11 |
| `ruvector-core` | `2.3.0` → `2.4.0` | critic only | 9 |
| `ruvector-turboquant` | `2.3.0` → `2.3.0` | critic only | 0 |

### Source-level used API proof

- `ruvector-sona`: 45 tracked files; exact SHA/blob parity for the complete directory.
- `ruvector-hybrid`: 6 tracked files; exact SHA/blob parity for the complete directory.
- `ruvector-solver`: 33 tracked files; exact SHA/blob parity for the complete directory.
- `ruvector-cognitive-container`: 9 tracked files; exact SHA/blob parity for the complete directory.
- `ruvector-gnn-rerank`: 10 tracked files; exact SHA/blob parity for the complete directory.
- `ruvector-turboquant`: 9 tracked files; exact SHA/blob parity for the complete directory.

- SONA: `reasoning_bank::{PatternConfig, ReasoningBank}`, `types::{LearnedPattern, QueryTrajectory, LearningSignal}`, `MicroLoRA::new/set_weights/forward/accumulate_gradient/apply_accumulated/get_weights`; entire implementation directory unchanged. Consumers: `sona_bridge.rs`, `parse_policy_training.rs`, candidate-forward/reload and restart tests.
- Hybrid: `Document`, `HybridSearch`, `RrfHybridIndex::build/search`; entire directory unchanged. Consumer: `da-mcp/src/hybrid.rs`.
- Solver: `types::CsrMatrix`, `forward_push::ForwardPushSolver`, `traits::SublinearPageRank::ppr_multi_seed`; entire implementation and features unchanged. Consumers: `kg-algorithms/src/{csr,ppr}.rs`, `kg-embeddings/src/ruvector.rs` behind `ppr`.
- Cognitive-container: `CognitiveContainer::new/tick/current_epoch/verify_chain`, `ContainerConfig`, `Delta`, `VerificationResult`; entire directory unchanged. Consumer: `da-adapters/src/agent_memory.rs`.
- Critic reflection: all 5 files in `ruvllm/src/reflection/` and all 11 in `ruvllm/src/claude_flow/` unchanged. `AgentType::Reviewer`, `ExecutionContext::new`, correctness/completeness/consistency checkers, `Perspective::critique`, `UnifiedCritique::combine` used by the deterministic critic are retained byte-for-byte.
- GGUF consumer: `CandleBackend::with_device(DeviceType::Cpu)`, `load_tokenizer(&Path)`, `load_gguf(&Path,&ModelConfig)`, `LlmBackend::generate(&str,GenerateParams)` and used public config fields remain source-compatible. Changed implementations are behavioral, not a signature removal. Compile unverified.

## Changed transitive runtime: standalone critic only

### ruvllm 2.5.0

Exact changed files are in JSON and `ruvector-ruvllm.diff`. Dependencies and feature definitions are unchanged; version is explicit 2.5.0 instead of inheriting 2.3.0. New additive `GenerationOutput`, `LlmBackend::generate_detailed` and `chat_template` have default implementations.

Candle backend now selects qwen2/qwen3 weight loaders by GGUF architecture and rejects unsupported/split files. Embedded tokenizer vocabulary, chat template, EOS/end-of-turn metadata and quantization are honored. Multiple model files in a directory now error. Generation uses one sampler per request, applies temperature once, resets KV caches correctly, serializes generations, and stream-v2 replays the real decode output after generation; no loaded model is an error rather than a mock stream. Blanket async stream still blocks inline; do not assume new true incremental async streaming.

This can change GGUF critic tokens, stop positions and verdicts even with an unchanged local model and prompt. No GGUF inference was authorized or run. The deterministic reflection path's vendor code is unchanged, but the selected `candle` implementation is compiled by the standalone tool and needs a compile check.

### ruvector-core 2.4.0

`src/index/hnsw.rs` now stores in-tree `FlatGraph` for ordinary f32 HNSW rather than `hnsw_rs::Hnsw`. Flat contiguous arrays, fixed seed 100, deterministic in-order batch linking, cosine normalization, and unclamped negative dot-product distances change search/build behavior. `VectorIndex::search_ef` is a new default method; `VectorDB::search` now honors the query's ef_search override. New opt-in `hnsw-structural-diagnostics` feature and a dev-only self-dependency enable regression tests; do not enable it in consumers needlessly.

Turbo4's HNSW implementation is unchanged and **still imports hnsw_rs**. Do not claim the transitive hnsw dependency disappeared.

## Lock files, features, MSRV and patches

- Root `Cargo.lock` sha256: `2de8f02a99ce4364118721215c85442710819d144080c697bef05c327e5ac17a`. RuVector-only update does not change root package versions, dependencies or features; **no RuVector-driven root lock refresh is expected**. Samyama is a separate audit.
- Standalone lock sha256: `79d862609a793b98baf9ea7eaa69f2c9c2bb792183bbcd4069bfe94d83dd18eb`. It names ruvllm/core 2.3.0; `--locked` cannot accept changed path versions. Refresh **only** those path package entries after source update, review the diff, preserve registry resolutions rather than running broad update.
- Standalone selected registry: candle-core/nn/transformers **0.9.2**, tokenizers **0.20.4**, bincode **2.0.1**, rkyv **0.8.18**, redb **2.6.4**, simsimd **5.9.11**, hnsw_rs **0.3.5**. Manifest ranges for these did not change. Both consuming locks, not vendor's broad workspace lock, are authoritative for what daily-archive compiles.
- Vendor `Cargo.lock` changes for many unrelated packages do not imply a consumer transitive refresh. Its hnsw patch entry remains **0.3.3**. Workspace root dependencies and package edition/MSRV remain unchanged.
- Declared MSRV: sona **1.70**, core/solver/cognitive-container/ruvllm workspace **1.77**, unused rvf-types/runtime **1.87**. No declared vendor MSRV increase. However existing standalone locked registry closure is already higher (cached `uuid 1.28.0` declares **1.89.0**, bincode/redb declare 1.85; no missing cached manifests among 270 registry records). daily-archive's pinned toolchain is **1.99.0**, not its declared 1.85. No compiler was invoked. Preexisting AVX512 feature requires 1.89 and lattice-embeddings 1.93, both disabled by the critic's explicit feature selection.
- `[patch.crates-io] hnsw_rs = {path="./patches/hnsw_rs"}` exists only at vendor workspace root. **It is not inherited by an external path dependency consumer.** Root consuming lock has registry **0.2.1** via Samyama; critic consuming lock has registry **0.3.5**. Their separate link units are intentional. Never propagate the 0.3.3 vendor patch to daily-archive casually: it would change standalone resolution and not fix Samyama 0.2.1.
- Upstream patch file fixes #773's layer-0 reachability/backlink-layer defects, removes stdout at 50k points, and adds diagnostics. In-tree ordinary core HNSW now bypasses this dependency, but Turbo4 still uses the registry hnsw path unless an independent root patch is deliberately configured.

## Unused declarations: API and persisted data implications

- agent-memory version remains 0.1.0. Adds default-compiled Ed25519 `SignedWitnessSink`, signed spans/anchors, `into_witness_sink`, `compact_witnessed`, and action `LEDGER_COMPACT_EVICT` **0xA7**. Existing canonical witness record remains 64 bytes; signed span/anchor is an added format, not automatic migration. Adds ed25519-dalek 2 alloc and optional mincut dependency/version; `mincut-forget` is new default-OFF feature. Coherence scoring refactors into `weighted_importance`. New graph-forget code contains upstream comments/tests relying on repeated mincut trials; do not import that policy or retry convention into this project.
- rvf-types: only Cargo.toml version **0.2.1→0.2.2**; all serialized type/header/flag source blobs unchanged.
- rvf-runtime: version 0.3.2/deps/features/MSRV unchanged. Only `store.rs` close path skips fsync for a read-only handle without a writer lock (Windows fix); no segment format change.
- gnn-rerank: directory unchanged. Not activated by a workspace declaration.

### Actual current persisted records are project-owned

`da-adapters::RvfFileStore` does **not** use vendor rvf-runtime/types. Its journal is `RVF1` + big-endian u32 length + JSON `da-ports::RvfRecord`, maximum 64KiB. Cognitive-container is reconstructed from these local trajectories on open; its source is unchanged. SONA candidate projection and manifest JSON is project-owned and vendor SONA source is unchanged. **No vendor-caused migration or data rewrite is required.** Do not run open/migrate/checkpoint methods on production data as an audit step.

Core `HnswState`, serializable config/metric layouts and bincode requirement are unchanged. Load rebuilds graph from vectors and IDs, now into FlatGraph, so old bytes should be field-compatible but recall/order may differ; no old-byte runtime roundtrip was run. Do not claim byte-format verification from version labels.

## WASM policy and hard locks

Current `WasmPolicyHost` uses **wasmi 0.51.5 / wat 1.258.0** from the root lock. Its project-owned ABI is `route(i32 pages,i32 bookmarks,i32 qmilli)->i32`, hashes compiled artifact bytes, and loads no vendor WASM library. Native SONA/solver feature selection does not select their WASM features. Latest `ruvector-wasm-v2.3.1` fixes IndexedDB persistence for a different binding, not this host.

No reason exists to rebuild, reload, hot-swap or deploy a policy artifact. Import eligibility remains false; deployed=false, graph_write=forbidden, auto_promote=forbidden, and candidate_id-only selection remain unchanged. No runtime/data/production writes.

## Graph evidence and unresolved boundaries

Bound GitNexus `daily-archive` (`/root/daily-archive`) before graph calls. Old index: `718be28b59cd3e52baded2f1245a8b7dfee12b01`, one commit stale; FTS disabled. RuVector external vendor repository is not indexed. General query returned no flows → **UNKNOWN**, not evidence of no consumers. Cypher identified relevant files; file impacts reported LOW (2 callers for bridge file, 3 for RVF file, 2 for critic file) and UNKNOWN for sona bridge. Function `build_reasoning_bank` resolved direct callers `run_sona_analyze` and its test, then CLI main. Struct/impl symbol ambiguity and missing imported-package crossings remain UNKNOWN; confirmed actual callers/imports by source as listed above. Parent is rebuilding a fresh complete index; **old LOW/UNKNOWN results are not credited as a final safe graph gate**. No HIGH/CRITICAL verdict was returned by these bounded old-index probes.

## Minimal checks after authorization (NOT RUN)

Run from `/root/daily-archive`, one cargo process at a time, after approved source fast-forward and any separately approved Samyama wiring. For each root test, normal in-memory/tempdir fixture writes are needed; they are not production writes. Do not run vendor-wide tests/workspace build. No cargo command ran during this audit.

```text
cargo test --locked -p da-application --lib sona_bridge
```
SONA bridge ReasoningBank.
```text
cargo test --locked -p da-application --test sona_restart_equivalence
```
persisted ReasoningBank restart; temp-only fixtures.
```text
cargo test --locked -p da-application --test parse_policy_training_reload
```
MicroLoRA candidate reload and no promotion.
```text
cargo test --locked -p da-mcp --lib hybrid
```
BM25+dense+RRF active consumer.
```text
cargo test --locked -p kg-embeddings --lib --features ppr ruvector::
```
PPR+bridge existing candidates only.
```text
cargo test --locked -p kg-algorithms --lib --features ppr ppr
```
PPR CSR shared Samyama/RuVector boundary; coordinate with Samyama owner.
```text
cargo test --locked -p da-adapters --test cvf_persisted_memory
```
cognitive-container replay against local RVF1 format in temp dirs.
```text
cargo test --locked -p da-adapters --test parse_experience_rvf
```
canonical local RVF1 journal framing.
```text
cargo test --locked -p da-adapters --lib wasm_policy
```
wasmi route ABI and digest hot-swap in temp dirs.
```text
cargo update --offline --manifest-path tools/learning-critic-ruvllm/Cargo.toml -p ruvllm -p ruvector-core
```
after approved source update only: targeted standalone path-version refresh, review diff and retain registry versions; not run by auditor.
```text
cargo check --locked --manifest-path tools/learning-critic-ruvllm/Cargo.toml --all-targets
```
standalone CPU candle compile without executing models.
```text
cargo test --locked --manifest-path tools/learning-critic-ruvllm/Cargo.toml --lib -- --skip gguf_critic::tests::gguf_determinism_two_runs_identical --skip gguf_critic::tests::gguf_verdict_path_and_discrimination
```
deterministic reflection and pure parsing helpers only, explicitly excludes both real-model tests.

**Do not use plain standalone `cargo test --lib`: its two model-gated GGUF tests will run when local models exist.** The explicit skips above are required under the no-inference restriction. `cargo check --all-targets` compiles those tests/binaries without executing them. New GGUF behavior needs a separate explicit inference authorization and reevaluation before relying on model verdicts.

Prebuild safe-update preparation: preserve current SHA `c6bb23…` as rollback reference, retain the three untracked directories, re-probe default HEAD if time passes, and fast-forward only to the audited `bfb257…`. No need to preserve a nonexistent local patch. Restore/build is the parent's authorized next step, not an action taken here.

## Assumptions and constants

- “Latest” means fresh exact origin default HEAD; release/tag scopes are listed separately.
- A workspace dependency declaration alone does not activate a crate; validated via manifests, source imports and both consuming locks.
- No build proof, GGUF behavioral proof or fresh-index all-clear is asserted.
- **Constants changed: none.** No config/source/data changes.

Artifacts: `ruvector-upstream.json` carries exact direct declarations, effective manifest diffs, full consuming RuVector lock closures (74 root records / 274 critic records, no ambiguous lock edges), changed paths, source-tree digests, revisions, releases and proposed checks. Reviewed focused diffs: `ruvector-{manifests,core,ruvllm,agent-memory,rvf-runtime}.diff`.
