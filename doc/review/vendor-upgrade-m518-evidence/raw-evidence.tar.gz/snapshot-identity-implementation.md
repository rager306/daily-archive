# M518 snapshot compatibility — storage-only source implementation

Status: source implementation complete. No Cargo, compiler, test suite or build was run. Parent owns later validation and the domain acceptance change. This worker is idle after handoff. No production graph/store, frozen evidence, manifest, GSD plan, parent documentation, vendor source, commit or push was touched.

## Authorized scope and sequence

Only repository file changed: `crates/kg-storage/src/snapshot_identity.rs` (inline focused tests).

The worker paused before edits on parent/user sequential instruction, then resumed as the only substantive worker. Parent explicitly approved catalog-presence v2, including an empty catalog, rather than equating absent and empty catalogs. Free disk before resume: 24.82 GiB. Free disk after source/fmt: 24.74 GiB. Required 15 GiB floor preserved. Temporary receipt files are a few KB; no new target or binary artifacts.

## Graph-first gate

Repository/worktree: daily-archive `/root/daily-archive`.
Fresh central index: `/root/.cache/gitnexus/vendor-upgrade-daily` at `eda16b4a496d8c177d2d6b1ab57e5feccf52a4cd`.
Both fingerprint_snapshot and fingerprint_snapshot_with_limits have **CRITICAL** risk: 15 impacted symbols, 6 modules, 10 CLI-main processes. Explicitly reported to parent before edits, and parent delivered the user warning. Do not waive with riskSharedAxes.
Receipt: `/tmp/vendor-upgrade-audit/snapshot-identity-pre-edit-graph.jsonl`.

Direct consumers include ReadOnlyServer::compute_identity, CLI snapshot-identity, load::enrich_snapshot_identity, and checkpoint/ontology examples. Source confirms agent-run expected-artifact identity, read-plane SnapshotIdentity equality, and GraphIdentity mapping that preserves the semantic hex without rehashing. The concept query was empty because FTS is disabled, and ambiguous domain contexts did not authorize any outside edit.

## Exact vendor evidence read

Pinned source only: `/root/vendor-source/samyama-graph-m518-17e55660`, audited upstream `17e55660ef90bc177ac9b55a1a22a9d39b41aa0f`.

- `src/snapshot/format.rs`: SnapshotIndexCatalog (193–197), SnapshotHierarchyIndex (161–173), header version stays 2.
- `src/index/catalog.rs`: externally tagged IndexDefinition (25–55).
- `src/vector/index.rs`: DistanceMetric L2/Cosine/InnerProduct, Quantization lowercase none/fp16.
- `src/snapshot/mod.rs`: always exports catalog (185–195), optional hierarchy (197–213), hierarchy serde/default restore (1200–1233), names/key catalog conflict rules (1303–1324).
- `src/index/hierarchy/monoid.rs`: RollupOp sum/count/min/max, ASCII-case-insensitive parser.
- AGENTS.md, ADR-040/051/061, samyama-upstream.md and samyama-persistence.md read first.

## Identity contract implemented

- `SEMANTIC_SNAPSHOT_ALGORITHM` remains exactly `sgsnap-vid-canonical-json.v1`.
- Without catalog or hierarchy records, the old payload shape, node/edge logic, canonical helper logic and digests remain unchanged.
- New constant `SEMANTIC_SNAPSHOT_ALGORITHM_V2 = "sgsnap-vid-canonical-json.v2"` is added. No existing constants, limits, paths or digests were changed.
- Any catalog record (including defaulted/empty definitions), or any hierarchy, selects v2. The algorithm string is inside the hashed payload, preventing cross-version identity ambiguity even for consumers mapping only the digest.
- v2 adds `index_catalog` and `hierarchies`. A missing catalog is JSON null; an explicit empty catalog is []. Presence is bound because the upstream importer treats these differently for index rediscovery.
- Local typed wire declarations work without enabling optional Samyama. Index variants are Property, UniqueConstraint, FullText, Vector; all declared fields are bound. Vector name defaults as the upstream Option field, metrics are exact L2/Cosine/InnerProduct, quantization exact none/fp16 (not DDL aliases).
- Catalog definitions and hierarchy declarations sort by canonical JSON. Hierarchy edge types sort/dedup. Ops lowercase, validate sum/count/min/max, sort/dedup. Hierarchy defaults bind reverse false, measures null, ops []; importer-effective count/sum fallbacks are NOT substituted.
- Duplicate catalogs, duplicate definitions, duplicate hierarchy names, conflicting full-text names, vector (label,property) keys or names fail. Property and UniqueConstraint on the same pair are allowed, as emitted upstream. Names in different index registries remain separate namespaces.
- Unknown record/enum/metric/quantization values, unknown declaration fields, malformed types and duplicate fields fail visibly. Declarations are deserialized from original JSON lines, not the intermediate JSON map, so duplicate fields cannot be overwritten silently. Legacy header/node/edge metadata tolerance is unchanged.
- Declared index identity is not assurance that runtime rebuild succeeded. Neither version promises a full-history backup, timestamps, durable import, sidecar queries/results, or encrypted snapshots. Export time, numeric IDs, ordering and legacy timestamps remain outside the identity exactly as before.

## Actual outside-file consumer blocker (parent accepted follow-up)

`crates/da-domain/src/corpus_checkpoint.rs:16` keeps `STRICT_SEMANTIC_SNAPSHOT_ALGORITHM` v1.
`SnapshotArtifactIdentity::validate` at lines 60–64 accepts ONLY v1, and `SnapshotIdentityEvidence::seal` at line 138 calls it. Thus the storage extension alone would leave v2 exports visibly rejected by:

- `crates/da-cli/src/snapshot_identity.rs:41–51` (seal),
- `crates/da-cli/examples/corpus_required_layer_checkpoint.rs` (artifact identity propagated),
- `crates/da-cli/examples/ontology_acceptance.rs:156–164` (artifact identity propagated).

Parent instructed this worker not to edit domain. Recommended/accepted next sequential step: graph-impact domain validate/seal, accept exact v1 and v2 while retaining the v1 constant and all old evidence; refuse unknown algorithms and add a focused domain test.

`load.rs` stores the algorithm string unchanged. `RemoteGraphStore::verify_identity` compares typed full identity; no v1-only assumption there. `da-ports::snapshot_to_graph_identity` omits the algorithm but retains the digest, which now cryptographically binds v2 inside the canonical payload. Existing read-plane unit fixtures and serde sample identities still explicitly use v1 and remain valid.

## Focused tests written, not executed

All 3 old tests retained. 8 new tests (11 total):

- `legacy_v1_raw_gzip_has_fixed_physical_and_semantic_identity`
- `explicit_empty_catalog_selects_v2_and_binds_presence`
- `v2_typed_declarations_have_fixed_identity_and_unordered_metadata`
- `v2_binds_each_declared_index_and_hierarchy_field`
- `hierarchy_wire_defaults_are_declared_not_importer_fallbacks`
- `malformed_declarations_and_unknown_wire_values_fail_closed`
- `duplicate_and_conflicting_declarations_fail_closed`
- `declaration_records_respect_existing_limits_and_graph_validation`

Fixtures use raw JSON-lines and a fixed independent gzip byte literal, not a Samyama encoder oracle. Fixed digests are SHA256 of independently authored canonical UTF8 literals preserved in `snapshot-identity-fixture-vectors.json`:

- legacy semantic: `9ccdc8704f3e6b58516b3d38508f211fae920548eb7a696d5f89314c96640f9d`;
- legacy physical gzip: `ee2860733cedf15e2272276c33e5dc3c21ab717dfb0d6e026715e1069ec1bd4d`;
- empty catalog v2: `31f6bc461ca0516866a68ba96b61eefba82cd94f172c6c843c98992a709218e2`;
- catalog + hierarchy v2: `efd9684afe0d5e581cdce227d04a497f6dd386524a6fb22211df1fa4d2f303c8`.

Tests cover v1 format 1/2, empty presence vs absence including h-only v2, supported declaration variants/fields, metadata/record/object ordering, numeric IDs, timestamp exclusion, uppercase/dedup op normalization, hierarchy ordering, declared vs importer-default ops, unknown/malformed/duplicate records, same-pair Property+Unique acceptance, collisions, limits/counts/dangling endpoint validation and v2 SnapshotIdentity JSON roundtrip.

## Source-only verification performed

No Rust semantic/type verification is claimed. Python inspection confirmed raw fixture JSON validity, pinned gzip decompresses to the raw fixture and physical SHA, and independently authored canonical literal digests. Before formatting, legacy parsing/canonical blocks and all old tests were compared byte-for-byte; after native formatting comparisons are {'legacy_algorithm_constant': True, 'legacy_n_e_dispatch_byte_equal': True, 'legacy_node_edge_canonicalization_byte_equal': True, 'legacy_canonical_helpers_byte_equal': True, 'legacy_tests_byte_equal': True}.

Final Rust-source actions only:
1. `rustfmt --edition 2024 --config skip_children=true crates/kg-storage/src/snapshot_identity.rs` — exit 0, no output.
2. `rustfmt --edition 2024 --config skip_children=true --check crates/kg-storage/src/snapshot_identity.rs` — exit 0, no output.

No Cargo wrapper or compiler was invoked. Formatting was confined to this file and happened after all source/test edits. Parent can later run focused `cargo test -p kg-storage --lib snapshot_identity` in the project's environment once compiler phase is allowed; this worker did not run it.

## Source hashes and locations

Before UTF8 source SHA256: `5e7b1a67463a2624c34a5ac2575263578887622bfa9bccad12341996e223881d`.
After file SHA256: `31bf372ce9aa3b3cafb0f92a34926a9b71ab4b5a35acdd110f85bb623c2e7ff0`.
Final source has 910 lines.

- `pub const SEMANTIC_SNAPSHOT_ALGORITHM_V2` — line 19
- `struct IndexCatalogRecord` — line 128
- `enum IndexDefinition` — line 140
- `struct HierarchyRecord` — line 180
- `"i" =>` — line 266
- `let has_declarations` — line 371
- `fn canonical_index_definitions` — line 403
- `fn canonical_hierarchy` — line 460
- `fn legacy_v1_raw_gzip` — line 637

Temporary audit files by this worker:
- snapshot-identity-pre-edit-graph.jsonl
- snapshot-identity-consumer-graph.mjs/.jsonl
- snapshot-identity-fixture-vectors.json
- snapshot-identity-implementation.md

No commits. No staging. Parent owns docs and final gates. Source implementation is ready for parent review; compilation and runtime validation remain pending by design.
