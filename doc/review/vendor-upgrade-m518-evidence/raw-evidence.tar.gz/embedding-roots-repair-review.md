# M518 content embedding-index composition repair — read-only review

Date: 2026-10-14.

## Verdict

**No material findings in the bounded repair.** Accept the absence-only CLI composition repair for the known content roots below. It fixes the legacy bare-Paper/PaperRevision declaration gap identified by the earlier journey review; acceptance is no longer journey-only.

This is **bounded content-root compatibility acceptance**, supported by current-source consumer review and focused hermetic runtime evidence. It is not whole-workspace/vendor-upgrade acceptance, a current full architecture-gate pass, live production ingestion, corpus recapture, or runtime execution of every CLI/example entrypoint. The known exclusions and proof limits below must travel with the acceptance.

## Correctness, locking, and preservation

- `crates/da-cli/src/production.rs:112–139`: `ensure_embedding_index` takes one concrete `store_write()` guard, checks `label.embedding`, and reads existing dimensions. An incompatible declaration returns an error without replacement. A compatible declaration returns without any mutation. Only an absent declaration reaches raw `create_index`, with caller-supplied dimensions and the existing cosine content-index policy.
- The check and creation are serialized under the same adapter store guard. There is no asynchronous graph-port call while that guard is held. The helper returns and drops the guard before its consumers call asynchronous add/materialization. Existing adapter adds take `store_read()` (`crates/kg-storage/src/samyama_adapter.rs:146–158,489–500`), so this repair does not introduce recursive lock acquisition or a new guard-across-await deadlock in these paths.
- Existing vectors, Arc identity, metric, precision/quantization, name mapping, and model binding remain authoritative. The helper calls neither model setter nor binding helper. Current vendor `src/vector/manager.rs:91–123` confirms unconditional creation would replace the index and clear its model record; `:197–221` still refuses an undeclared add. Current `src/vector/index.rs:374–385` still refuses dimension mismatch before mutation and retains equal re-add/conflict semantics. This repair does not weaken those vendor/storage contracts.
- The helper lives in the concrete CLI product layer. Product labels are chosen there/by its CLI consumers, not added to universal KG storage. No application/shared-writer/kg/vendor implementation edit is part of this repair. The earlier CRITICAL shared-writer boundary was not expanded.

## Known consumer wiring and error policy

| Content root | Source-confirmed behavior |
|---|---|
| Journey first attach | `load_journey.rs:455–505` calls the helper only in the existing unstamped-Paper `None` arm, using injected `ports.embedder.dimensions()`. Existing equal-SHA no-op and changed-SHA `EmbedStale` scheduling branches are unchanged. Add still precedes a successful-write-only SHA stamp. Helper/add/stamp errors still fail the journey. |
| Legacy `da load` content path, including journey fallbacks | `load.rs:384–434` constructs one configured `FdApiEmbedder`, passes that same instance into `embed_with_cache`, and declares `PaperRevision` when revision context exists, otherwise `Paper`, before materialization. `embed_with_cache` (`:859–950`) retains its model/cache key, cache payload dimension check, credential, and error behavior. Helper errors return through the existing content Result; no success is manufactured. |
| Single ingest | `main.rs:1310–1365` captures dimensions from the configured embedder before moving it into the use case. The resolved revision context selects exactly the label the materializer will write. A declaration error exits nonzero before ingest, matching the command's existing fatal setup/ingest policy. |
| Batch ingest | `main.rs:1453–1479,1500–1558` builds contexts in parallel with resolved PDFs and declares only the labels required by those contexts: `Paper` for any versionless item, `PaperRevision` for any versioned item. It uses dimensions from the same configured embedder passed to the batch use case. Incompatible required state is a nonzero root setup refusal; unrelated unused labels are not inspected. |
| Scheduler content writers | `main.rs:2616–2674` restores supplied scheduler state before checking/declaring `Paper`, then constructs executors and starts `run_due`. Source confirms current Ingest/Reparse executors call versionless `ingest_pdf` (`scheduler_executors.rs:177–300`), and EmbedStale replaces `Paper.embedding` (`:304–424`); `PaperRevision` is not needed by these executors. `FdApiEmbedder::from_env` uses the same configured/default dimension behavior for the initializer and executors. A declaration conflict returns the existing root `anyhow::Result` before task claiming/execution; executor retry/SHA policies are unchanged. |
| Offline revision canary | `revision_graph_canary.rs:69–79` declares `PaperRevision` with two dimensions, matching the already-present two-element vectors (`:95,193`), before wrapping the store for replay observations. Errors propagate through the example Result. No canary constant/vector/assertion was changed. |
| Offline catalog materializer | `catalog_materialize_runner.rs:593–612` retains the concrete store and its abstract handle over the same Arc, including resume import. `:735–782` declares `PaperRevision` from each cached vector's length before ingestion. The artifact loader rejects empty vectors (`catalog_materialize.rs:448–474`). A conflicting existing declaration is not rebuilt: the error flows through the existing per-paper `materialize` failure FSM, skips extraction/replay for that paper, records failure, and continues the run. Existing replay/export policy is unchanged. |

The consumer labels agree with the actual materializer branch (`ingest.rs:796–829`: revision context → `PaperRevision`, no context → `Paper`). The materializer continues to require its embedding write and propagate failure (`:1128–1146`). No generic auto-indexing, missing-index fallback, model enforcement, or backfill was added.

## State-based regression evidence

- `embedding_index_composition_test.rs:46–86` preserves strict missing-declaration failure in a fresh real embedded store and checks no SHA stamp/no index. It does not imply all structural writes roll back; the test correctly observes a Paper already exists after failed materialization.
- `:88–172` exercises fresh real `Paper` **and** `PaperRevision` declarations, successful materialization, nearest-neighbor retrieval of the expected node, dimension/cosine/count-one checks, retained candidate-only/import locks, and replay retaining SHA/node/edge/vector counts.
- `:174–250` seeds a populated named L2/FP16 `PaperRevision` index and model binding. Incompatible dimensions refuse; compatible ensure preserves the original Arc, metric, quantization, dimensions, name, binding, vector count and searchable seed, without node/edge mutation.
- Existing journey tests retain bare-store/search/replay coverage plus a distinct seeded Paper with named FP16/model preservation, and incompatible-index refusal with no new-Paper SHA stamp. Their current file hash remains `0a63ccfdba2a7099b94a1df870f66448f3c8f5f8d9307d43652109e8b32c4913`, matching the earlier journey-review binding. The inspected journey-test diff is addition-only; no original success, lineage, cache, graph-idempotence, SHA, candidate-only, or import-lock assertion was removed.
- No new choreography/magic-error-string test is used to substitute for stored-vector state. The focused evidence proves the helper/materializer contracts and journey runtime behavior. CLI single/batch/legacy/scheduler consumer wiring was reviewed in source, not independently run against real services.

## Exact source binding

All seven current SHA-256 values match `embedding-roots-clippy-after-lint.json`. They were rechecked unchanged at the end of this review.

| Source | Current SHA-256 |
|---|---|
| `crates/da-cli/src/production.rs` | `bd862b3262056d495d599956ba4228542306f8ad406f6f88f5861be0aa7710d9` |
| `crates/da-cli/src/load_journey.rs` | `5e881db98abe0a1a44872be19130aadc5f2b1cabb8f791714385fde1505b17dc` |
| `crates/da-cli/src/load.rs` | `2ed5631bb516dcaa0fb7f3ec7f66ddd4d23e98b60ea53a7b2902bb287c49abb4` |
| `crates/da-cli/src/main.rs` | `ee5c883a4562f7644309254ea84e7b5319f6e723cdd5eff903463ccdbeac838a` |
| `crates/da-cli/tests/embedding_index_composition_test.rs` | `70ba25faaea95e161bb3516a7e7eb08b1f1bc3975143e00cc04f740567a6792d` |
| `crates/da-cli/examples/revision_graph_canary.rs` | `69c6abb41bdbab0a22d6287a45985fbcd690f11dcea5d49790f884a7f5515551` |
| `crates/da-cli/examples/catalog_materialize_runner.rs` | `9f4b7090c20b5e4a664e2278e6dc1aa5cc1a9b86bc83b3b0d620a99a556eb5ac` |

The default and `pdf-layout` test receipts bind **the same current bytes for six files**, but bind the preceding `main.rs` hash `3d0ddab9d4c07f07fb4f2390b00c6d7f025c6d508a2c9388fc365df0644e69a7`. The retained initial clippy failure is exit **101** for `collapsible_if` in the batch initializer. `embedding-batch-lint-repair.json` discloses the subsequent main-only rewrite to `if !required { continue; }` plus the same flat error branch; the other six hashes are unchanged.

I reconstructed the preceding main bytes in memory by reversing only that batch block. The reconstructed SHA-256 equals the test receipt hash exactly. The control flow is equivalent: the old block runs the helper/error branch iff `required`; the new block continues iff not required and otherwise runs that same helper/error branch. This is source-equivalence review plus current clippy compilation, **not post-flatten runtime test proof**. No lint suppression or let-chain was introduced.

Current vendor source bytes inspected for the locking/declaration contract match the existing verification binding: `manager.rs` SHA-256 `69000b757bf3fa97e3606328b0d89383ee187bd2a7a96f0bbc8c5bed2f67bcb6`; `index.rs` SHA-256 `b8f8d219fe367b8942ae3005b5f1166b025cce23990e1078114adfd3fa01075f`.

## Supplied verification and limits

Receipts and corresponding logs were read; **this reviewer ran no compiler, tests, examples, or stores**.

| Supplied evidence | Actual result | Limit |
|---|---|---|
| `embedding-roots-focused-tests.json/.log` | Exit 0; **14 passes**: composition 3, governed-process 2, journey 9 | Default feature selection; fresh hermetic embedded stores/fakes; pre-flatten main hash. |
| `embedding-roots-layout-tests.json/.log` | Exit 0; **14 passes**, same 3/2/9 targets | `pdf-layout`; same cases in another feature configuration, not 28 distinct tests; pre-flatten main hash. |
| `embedding-roots-clippy.json/.log` | Retained exit **101**, batch `collapsible_if` | An actual initial failure, not erased by the repair. |
| `embedding-roots-clippy-after-lint.json/.log` | Exit **0** on current seven source hashes | `pdf-layout`, binary `da`, three focused test targets, and two examples, `--no-deps -- -D warnings`. Dependencies still emit warnings in the log; this is not a vendor-wide warning-free claim. Examples compile only; neither example was run or recaptured a corpus. |

All supplied commands used `--locked --offline -j 1`, `CARGO_BUILD_JOBS=1`, `CARGO_NET_OFFLINE=true`, and invocation-only `CARGO_PROFILE_DEV_DEBUG=0` / `CARGO_PROFILE_TEST_DEBUG=0`. The focused commands select `embedding_index_composition_test`, `governed_process_record_test`, and `load_journey_test`; the layout command adds `--features pdf-layout`. The final clippy command additionally selects `--bin da`, `--example revision_graph_canary`, and `--example catalog_materialize_runner`. No changed source profile, test selection, assertion, optimization policy, or constant is required by this review.

The old architecture run remains **19 completed: 17 pass, 2 fail; step 20 resource-interrupted; steps 21–23 not run**. These focused results do not convert that historical run into a current full gate pass. The earlier narrow journey review also remains an earlier source/receipt revision; it is not silently reused as proof for this broader patch.

## Acceptance scope, assumptions, and known exclusions

- Fresh declarations reuse the existing cosine policy; existing dimensions/metric/name/precision/model remain authoritative. The canary's two-dimensional declaration follows its existing two-element input, not a new numeric policy. **No constants were changed.**
- Offline catalog has cached vector length, not independent model/dimension identity. The repair does not establish model provenance or enforce same-model compatibility. Raw vector indexes can remain model-unknown, and an existing model binding is preserved rather than reinterpreted.
- Optional `Entity.embedding` readiness is **not accepted or proved** here. The earlier known warning/no-successful-vector behavior when that optional writer lacks a declaration remains outside content embedding-root acceptance. Do not claim Entity vector readiness or a process failure that was not observed.
- The known `samyama_hot_path_profile` example's bare `HotNode.vec` path is **not repaired or accepted** here. Its earlier source-based missing-index risk remains deferred; this report does not claim all examples or every universal vector writer is compatible. Gold flows receiving caller-supplied abstract stores likewise gain no universal readiness guarantee from this repair.
- Existing SHA-only/partial historical state is **not backfilled**. Equal-SHA paths keep their old no-op policy, and declarations alone do not recover absent stored vectors. Nothing here proves migrated production contents or an existing graph fully embedding-ready.
- The known legacy required Paper/PaperRevision content gap is now repaired at its roots and is not silently excluded. Acceptance covers the named content paths' index composition plus the tested contracts, with runtime-entrypoint limits explicitly stated above. Whole-upgrade acceptance still needs the parent's remaining verification/closeout work and cannot be inferred from this review.

Graph-first navigation evidence was supplied in `embedding-roots-preedit-impact.jsonl` and `embedding-roots-scheduler-impact.jsonl` (journey MEDIUM; ingest/batch/scheduler LOW; production File, trait root and canary UNKNOWN). UNKNOWN was not treated as safe/unreferenced: current source and `embedding-roots-unknown-source-confirmation.json` were used to confirm these roots. The old daily index at `/root/.cache/gitnexus/vendor-upgrade-daily` is structural evidence only; it was not refreshed after the repair, and no graph freshness or exhaustive caller-census claim is made.

Review operations: bounded receipt/log/current-source reads, supplied graph-evidence reads, one read-only scoped git diff, in-memory hash/equivalence checks, and this report. No source edits, compile/test, index refresh, inventory expansion, cleanup, production graph/store opening, network, inference, import, push, promotion, GGUF work, or generic migration. Candidate-only/import/deploy/graph-write/auto-promotion locks are unchanged.
