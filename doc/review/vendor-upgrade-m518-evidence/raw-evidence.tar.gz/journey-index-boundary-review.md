# M518: missing vector-index boundary review

Date: 2026-10-14. Scope: read-only source and existing failure captures. No cargo, tests, index refresh, store execution, network, inference, implementation edits, or frozen M517 edits were performed.

## Decision

Provision **only an absent `Paper.embedding` index in `run_journey_content`**, immediately before the existing `None => add_vector` path (`crates/da-cli/src/load_journey.rs:489–493`). This is the journey's concrete composition boundary: it already has the configured/injected embedder and `Arc<SamyamaGraphStore>` and owns the Paper vector attachment.

Use `ports.embedder.dimensions()` and the existing **cosine** index policy. Check existence and create under the **same `store_write()` guard**. Drop that guard before calling the existing asynchronous `add_vector`. Preserve an existing index exactly; do not rebuild it, reset its binding, or change its dimension/metric/quantization/name. Leave the SHA, stale-embedding scheduling, add failure, and SHA-stamp behavior unchanged.

A fixture-only fix is insufficient: the production journey opens a new bare process-local store too. The shared application embedding writer is the wrong repair boundary and has CRITICAL impact. The universal storage adapter must continue refusing a missing index, not invent product labels or auto-index every add.

## Observed failure and why it is real

Both existing captures, `full-architecture-step-captures/16.stdout.log` and `18.stdout.log`, report these two failures:

- `hermetic_figures_journey_binds_real_data_policy_and_registry`
- `journey_refuses_a_registry_that_disagrees_with_emitted_lineage`

They stop at `journey vector attach: ... no vector index for Paper.embedding; vector for node 1 was not stored`. Step 16 is default `da-cli --tests`; step 18 is `pdf-layout --tests`; both completed with exit 101 and `timed_out=false`. The latter test therefore never reaches the figure-lineage refusal its existing assertions require (`governed_process_record_test.rs:611–621`). Do not weaken those assertions.

The tests create bare stores (`governed_process_record_test.rs:467,579`), and `run_figures` forwards them unchanged into the production journey (`:425–452`). The fake embedder declares three dimensions; production should not hardcode that value. `load_journey_test.rs:270–279` has the same bare-store/injected-port composition.

The new missing-index error is intentional, not a vendor regression to undo. Current vendor `src/vector/manager.rs:197–221` refuses a raw add that formerly reported success without storing a vector. The root adapter propagates it (`crates/kg-storage/src/samyama_adapter.rs:489–500`; inherent hot path `:146–158`).

## Production ownership: no initializer already covers this path

- `ProductionContext::new` only initializes cache, clock, and stage registry; it preserves the supplied store (`crates/da-cli/src/production.rs:64–98`). `from_env` opens a new store (`:100–107`). No embedder or vector-index declaration is available in that constructor.
- `make_content_pipeline` accepts that store, calls the constructor, and injects `JourneyPorts::from_env` when requested (`crates/da-cli/src/load.rs:1157–1183`). The default open returns `try_from_env` without index setup (`:1203–1210`). Single load and batch load use this path (`:1291–1293`, `:1417–1418`).
- `SamyamaGraphStore::new` constructs a new raw store; `from_env` adds the tenant, not a vector index (`crates/kg-storage/src/samyama_adapter.rs:34–59`).
- `schema_init` does declare `Paper.embedding` with a supplied dimension and cosine (`crates/da-cli/src/main.rs:2327–2373`). It opens **its own** store (`:2340`). The same CLI documents that these stores are process-local and disappear on exit (`:64–68`, `:105–106`). A preceding `da schema init` therefore does not initialize a later `da load --journey` process.
- `ensure_materialization_indexes` is a **property-index** policy, not a vector-index initializer (`crates/da-application/src/materialization_indexes.rs:23–49`). It cannot be reused as though it provisioned embeddings.

`run_journey_content` is already an infrastructure-level journey composition function, not a pure application use case. Its signature injects the concrete store and embedder (`load_journey.rs:88–95,232–249`). Adding the conditional declaration here does not create an application→adapter dependency or a universal kg-storage product policy.

## Exact minimal repair shape (recommendation only)

Inside the existing first-attach `None` arm, before `store.add_vector`:

```rust
{
    let graph = store.store_write().await;
    if graph.vector_index.get_index("Paper", "embedding").is_none() {
        graph
            .vector_index
            .create_index(
                "Paper",
                "embedding",
                ports.embedder.dimensions(),
                samyama::vector::index::DistanceMetric::Cosine,
            )
            .map_err(|error| format!("journey vector index: {error}"))?;
    }
}
// Existing add_vector and successful-write-only SHA stamp remain unchanged.
```

The CLI already depends on `samyama` (`crates/da-cli/Cargo.toml:376`). No new port, dependency, global helper, environment key, or hardcoded test dimension is needed. The public concrete write guard exists at `kg-storage/src/samyama_adapter.rs:87–89`.

Do not invoke the async `GraphStore::create_vector_index` while holding `store_write`: that method acquires a read guard (`samyama_adapter.rs:312–328`). Use the raw manager under the guard and release it before any async port operation. The write guard makes the existence check and creation mutually exclusive with other accesses through this concrete store.

### Dimensions, metric, binding, and equality

- Derive the declaration dimension from **`ports.embedder.dimensions()`**, not the vector length. The embed stage records dimension/model in its cache contract and validates returned length (`crates/da-adapters/src/pipeline_stages.rs:143–157,219–227`). A malformed cached vector must not silently define a different index dimension.
- Cosine is the existing Paper index policy (`main.rs:2372`), not a new constant change. An existing incompatible dimension remains intact and the existing add fails with `DimensionMismatch` (`vendor src/vector/index.rs:374–385`). Do not suppress that error or replace the index to make the test pass.
- Vendor `create_index` is **not idempotent**: `create_index_quantized` installs a new empty index and removes its model record (`vendor src/vector/manager.rs:91–123`). Calling it unconditionally would destroy already stored vectors and model provenance.
- Current raw `add_vector` does not validate or establish model identity (`manager.rs:198–221`). `set_model_id` overwrites/clears the record, while `bind_model_if_unset` preserves an existing binding (`:126–184`). The minimal repair should **not call either**: preserve the raw-vector writer's current semantics and any existing binding. A newly created raw index remains model-unknown, as described by the vendor (`:30–38`). The journey's model fingerprint still binds the embedding cache. Do not claim this repair adds model-mismatch enforcement; that is a separate policy change.
- Existing index names and quantization also remain untouched. New raw `create_index` uses `Quantization::None`; it creates no named-index alias (`manager.rs:52–73,91–100`).
- The existing journey SHA guard remains: equal fingerprint is a no-op; changed fingerprint schedules `EmbedStale`; only an unstamped Paper gets `add_vector` followed by a successful-write-only SHA stamp (`load_journey.rs:455–498`). Vendor equal re-add is a no-op, conflict is an error, and equality is at the stored precision (`vector/index.rs:351–385`). Do not route this repair through replacement or change those semantics.
- This repair does **not** backfill old falsely successful SHA-only nodes. Do not conflate migration repair with provisioning the missing declaration; a SHA stamp alone is not evidence of a stored vector.

## Graph impact and its limits

Daily index: `/root/.cache/gitnexus/vendor-upgrade-daily`, `indexedAt=2026-10-14T08:06:41.936Z`, commit `eda16b4a496d8c177d2d6b1ab57e5feccf52a4cd`. All seven inspected daily source hashes (journey, load, production, the two test files, adapter, shared writer) match its recorded file hashes. Read-only LocalBackend calls were bound to this index. No refresh was run.

Evidence: `journey-boundary-preedit-impact.jsonl` plus the `journey-boundary-*-read.jsonl` and `journey-boundary-index-callers.jsonl` files beside this report.

| Candidate | Upstream impact | Decision |
|---|---|---|
| `run_journey_content` | **MEDIUM**, 10 impacted, 6 direct callers, 1 process group, 2 modules | Preferred edit. |
| `make_content_pipeline` | LOW, 5 impacted, 3 direct callers, 1 process group, 2 modules | Does not cover direct journey callers; would require avoidable constructor/async changes. |
| `write_node_embedding` | **CRITICAL**, 30 impacted, 5 direct callers, 5 process groups, 11 modules | Explicit high-risk warning: do not edit for this repair. |
| The three named existing test functions | **UNKNOWN**, no resolved upstream callers | Source-confirmed `#[tokio::test]` entrypoints at load test `:269–270` and governed tests `:464–465,576–577`; not unused symbols. |

The journey impact includes `CliContentPipeline.run_content_journey → run_journey_content` and the equations/tables/figures test branches. Graph resolution does not cover every trait/async call: in particular source confirms `run_figures → run_journey_content` (`governed_process_record_test.rs:434`) and `run_journey_versioned → run_journey_content` (`load_journey_test.rs:248`), despite incomplete graph call edges. The counts are not an exhaustive consumer census.

The vendor index was built before the current local vector repairs: its manager/index file hashes do not match the current files. It was used for structural navigation only; every vendor semantic claim above was confirmed against the current on-disk source and its source binding in `verification-progress.json`.

## Narrow follow-up consumers (predictions, not executed results)

1. **Later journey tests:** successful default/release-cache/equations/tables/figures paths and the tampered-lineage negative path in `crates/da-cli/tests/load_journey_test.rs` (`:270,426,588,691,1072,1181`) use bare stores. The logs never reach this test target. They are likely additional symptoms of the same journey boundary. The no-detector negative test (`:792`) rejects at composition before vector attachment; do not classify it as a missing-index failure.
2. **Legacy load and ingest:** graph path `CliContentPipeline.run_content → IngestUseCase.materialize_parsed_with_context → write_node_embedding`; source load `:398–422`, ingest `:1135–1146`. The target label is `PaperRevision` for a revision context, otherwise `Paper` (`ingest.rs:817–829`). Legacy CLI `ingest_pdf` opens a fresh `ProductionContext` and injects it into the use case (`main.rs:1310–1325,1347–1349`). No vector declaration covers either label in those constructors. This requires a separate composition-boundary decision, not expanding the journey fix or changing the CRITICAL shared writer.
3. **`revision_graph_canary` example:** graph `main → materialize_parsed_with_context`; bare concrete store and revision vectors are source-visible at `crates/da-cli/examples/revision_graph_canary.rs:69–75,88–99`. It has no vector initializer, so its first revision embedding write is likely to refuse.
4. **`catalog_materialize_runner` example:** graph `async_main → run_materialization → materialize_parsed_with_context`. It opens the concrete store, optionally imports state, and only ensures property indexes (`:593–619`); materialization receives vectors at `:736–742`. A fresh run without an imported matching vector index is exposed. A restored index may change the outcome; do not claim every resume fails.
5. **`samyama_hot_path_profile` example:** graph `main → SamyamaGraphStore.add_vector_direct`. It opens a new store at `:76` and writes `HotNode.vec` at `:124–134` without declaring an index. Its first add is likely to error. Its label/property/dimension are owned by that example, not the journey or universal adapter.
6. **Entity extraction:** graph `materialize_extracted_with_context → write_entity_embedding → write_node_embedding`; source `crates/da-application/src/extraction.rs:385–424,850–855`. When the optional embedder is configured and `Entity.embedding` is absent, this writer emits the existing `entity_embedding_write_failed` warning and does not increment successful embedding writes. It is a missing-vector risk, **not necessarily a failing test/process**, because extraction intentionally continues under its existing policy.

`materialize_wave → materialize_parsed_with_context` is also graph-confirmed (`gold_graph.rs:1232–1242`), but it accepts a supplied abstract store and therefore is not evidence that every gold composition uses an uninitialized concrete store. Existing mock-based lib passes are not embedded-index initialization proof. Explicitly provisioned storage contract tests (`kg-storage/tests/vendor_compatibility.rs:9–13,72–77`) are useful controls, not affected bare-store examples.

## Minimal verification after the parent's repair

Keep every existing success, candidate-only/import lock, policy, lineage refusal, cache, graph-idempotence, and SHA assertion.

1. Extend `journey_content_completes_and_replays_over_file_cache`: retain the bare store; assert a positive nearest-neighbor hit for the expected Paper with the known injected vector, index dimensions from the injected embedder, cosine metric, and exactly one stored Paper vector. Repeat after replay. The existing SHA-only check (`load_journey_test.rs:326–334,377–384`) cannot prove a vector was stored.
2. Add one state-based existing-index preservation case: predeclare a compatible populated Paper index, bind it to the same fake model, seed another Paper vector, then run a new unstamped Paper journey. Confirm both vectors remain searchable and the original index `Arc`, binding, dimensions/metric, and count are retained. Replay must retain them again. A same-Paper replay alone would miss unconditional creation hidden inside the `None` arm.
3. Add one incompatible-existing-dimension case: predeclare a populated index with a different dimension, run the ordinary bare-store journey with its unchanged embedder, assert failure, and confirm the original declaration/vector/binding remains intact and the new Paper lacks the SHA stamp. Assert state and rejection, not a magic error string. No re-index or dimension fallback is permitted.

Run one cargo process at a time, first the two focused targets; recommended commands, **not executed in this review**:

```text
cargo test --locked --offline -j 1 -p da-cli --test governed_process_record_test
cargo test --locked --offline -j 1 -p da-cli --test load_journey_test
```

Then validate the relevant feature combination and finish the remaining architectural gate only under the parent's verification/resource plan. Run cargo fmt as the final Rust task action, followed by the required fmt check; run graph change analysis before commit.

## Honesty and locks

No constants were changed. The recommendation reuses the existing cosine policy and injected dimension. The full gate remains **17 passes / 2 failures among 19 completed steps**. Step 20 was resource-interrupted (`-9`) per the parent's verification record, not a test result; steps 21–23 were not run. This report is diagnosis, not compiled or test-pass evidence, and does not authorize closeout. `import_eligible`, deployment, graph-write, and auto-promotion restrictions remain unchanged.
