import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

ROOT = Path("/root/daily-archive")
CAPTURES = Path("/tmp/vendor-upgrade-audit/full-architecture-after-content-repair-step-captures")
CAPTURES.mkdir(exist_ok=True)
PROTECTED = [Path(p) for p in ['/tmp/policy-resume-audit/frozen-runners/policy_corpus_capture', '/tmp/policy-resume-audit/frozen-runners/policy_corpus_evaluate', '/root/daily-archive/artifacts/learning/policy-corpus-m517/manifest.json', '/root/daily-archive/artifacts/learning/policy-corpus-m517/experiment.yaml', '/root/daily-archive/artifacts/learning/policy-corpus-m517/parse_pair_metric.yaml', '/root/daily-archive/artifacts/learning/policy-corpus-m517/registry.yaml', '/root/daily-archive/artifacts/learning/policy-corpus-m517/cycle-060.json', '/root/daily-archive/artifacts/learning/policy-corpus-m517/cycle-120.json', '/root/daily-archive/artifacts/learning/policy-corpus-m517/cycle-240.json', '/root/daily-archive/target/debug/m518-ledger-new-probe', '/root/daily-archive/target/debug/deps/parse_job_ledger_test-8bd6c3ce11db3d11', '/root/daily-archive/data/vendor_patches/samyama-m518-vector-wcc.patch']]
PROTECTED_HASHES = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in PROTECTED}
_original_run = subprocess.run
_count = 0


def native_compilers():
    rows = []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit():
            continue
        try:
            cmd = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            if cmd.startswith("/bin/bash"):
                continue
            if any(s in cmd for s in ["/bin/cargo ", "/bin/rustc ", "/bin/clippy-driver ", "cc1plus"]):
                rows.append({"pid": int(proc.name), "command": cmd})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return rows


def supplemental(command, label, records):
    started = time.monotonic()
    result = _original_run(command, cwd=ROOT, capture_output=True, text=True, timeout=3600)
    record = {"label": label, "argv": command, "exit_code": result.returncode, "duration_seconds": time.monotonic() - started, "timed_out": False}
    (CAPTURES / f"{label}.stdout.log").write_text(result.stdout or "")
    (CAPTURES / f"{label}.stderr.log").write_text(result.stderr or "")
    records.append(record)
    if result.returncode != 0:
        raise RuntimeError(f"supplemental capacity/provision step failed: {label}; exit {result.returncode}")
    return result


def prepare_next_feature(number):
    # Cargo clean removes derived CLI outputs, not successful-step captures.
    previous = json.loads((CAPTURES / f"{number - 1:02d}.json").read_text())
    if previous.get("status") != "complete" or previous.get("exit_code") != 0 or previous.get("timed_out"):
        raise RuntimeError("previous feature suite did not pass; stop before cache maintenance")
    rows = native_compilers()
    if rows:
        raise RuntimeError(f"native compilers active before owned CLI cleanup: {rows}")
    records = []
    prefix = f"before-{number:02d}"
    receipt = {"before_native_step": number, "status": "running", "previous_step": previous, "commands": records, "protected_hashes_before": PROTECTED_HASHES}
    path = CAPTURES / f"{prefix}-capacity.json"
    path.write_text(json.dumps(receipt, indent=2))
    try:
        clean = ["cargo", "clean", "--locked", "--offline", "--target-dir", str(ROOT / "target"), "-p", "da-cli"]
        dry = supplemental(clean + ["--dry-run", "--verbose"], prefix + "-cli-clean-dry", records)
        for line in dry.stdout.splitlines() + dry.stderr.splitlines():
            text = line.strip()
            if not text.startswith("/"):
                continue
            item = Path(text)
            if not item.parent.resolve().is_relative_to((ROOT / "target").resolve()):
                raise RuntimeError(f"clean plan escapes owned target: {text}")
            if any(t in text for t in ["m518-ledger-", "parse_job_ledger_test", "vendor_compatibility", "kg_storage", "policy-resume-audit", "artifacts/"]):
                raise RuntimeError(f"clean plan selects a protected path: {text}")
        if native_compilers():
            raise RuntimeError("compiler appeared after dry run; no cleanup allowed")
        supplemental(clean, prefix + "-cli-clean", records)
        if native_compilers():
            raise RuntimeError("compiler active before shared compiler-cache cleanup")
        supplemental(["kache", "clean", "--cache", "--yes"], prefix + "-compiler-cache-clean", records)
        current = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in PROTECTED}
        if current != PROTECTED_HASHES:
            raise RuntimeError("protected runner/artifact hash changed during supported cleanup")
        # Later feature suites also execute the same default runners; restore
        # their native default feature selection after cleaning CLI outputs.
        for earlier in [14, 15]:
            original = json.loads((CAPTURES / f"{earlier:02d}.json").read_text())["argv"]
            supplemental(original, prefix + f"-restore-default-{earlier:02d}", records)
        receipt.update(status="complete", protected_hashes_unchanged=True)
    except BaseException as error:
        receipt.update(status="failed", error=str(error), timed_out=isinstance(error, subprocess.TimeoutExpired))
        raise
    finally:
        path.write_text(json.dumps(receipt, indent=2))


def capture_run(command, *args, **kwargs):
    global _count
    is_step = isinstance(command, list) and command and command[0] == "cargo" and Path(kwargs.get("cwd", ".")) == ROOT
    if not is_step:
        return _original_run(command, *args, **kwargs)
    _count += 1
    number = _count
    if number in [17, 19]:
        prepare_next_feature(number)
    started = time.monotonic()
    metadata = {"number": number, "argv": command, "cwd": str(ROOT), "timeout_seconds": kwargs.get("timeout"), "status": "running", "timed_out": False}
    record = CAPTURES / f"{number:02d}.json"
    record.write_text(json.dumps(metadata, indent=2))
    try:
        result = _original_run(command, *args, **kwargs)
    except subprocess.TimeoutExpired as error:
        metadata.update(status="timed-out", exit_code=None, timed_out=True, duration_seconds=time.monotonic() - started)
        stdout, stderr = error.stdout or "", error.stderr or ""
        (CAPTURES / f"{number:02d}.stdout.log").write_bytes(stdout if isinstance(stdout, bytes) else stdout.encode())
        (CAPTURES / f"{number:02d}.stderr.log").write_bytes(stderr if isinstance(stderr, bytes) else stderr.encode())
        record.write_text(json.dumps(metadata, indent=2))
        raise
    else:
        metadata.update(status="complete", exit_code=result.returncode, duration_seconds=time.monotonic() - started)
        (CAPTURES / f"{number:02d}.stdout.log").write_text(result.stdout or "")
        (CAPTURES / f"{number:02d}.stderr.log").write_text(result.stderr or "")
        record.write_text(json.dumps(metadata, indent=2))
        return result


subprocess.run = capture_run
sys.argv = ["governor", "architecture"]
runpy.run_module("governor", run_name="__main__")
