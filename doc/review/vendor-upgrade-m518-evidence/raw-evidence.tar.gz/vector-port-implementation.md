# Scoped Samyama vector + WCC semantic port

## Result and execution limits

Implemented only in `/root/vendor-source/samyama-graph-m518-17e55660`, detached at exact upstream `17e55660ef90bc177ac9b55a1a22a9d39b41aa0f`.

Changed source files:

- `src/vector/index.rs`
- `src/vector/manager.rs`
- `crates/samyama-graph-algorithms/src/community.rs`

The shared `/root/vendor-source/samyama-graph` sources, original patchsets, dependencies, manifests, config, operational stores and production data were not edited. The pre-existing candidate `?? .cargo/` remains unchanged. No cargo, compiler, build, test, benchmark, network-enabled runtime, store open, commit or push was run. Native rustfmt parsed/formatted only the three scoped Rust source files, after every source/test edit.

**This is source + formatter evidence, not compiled or passing-test evidence.** Parent owns subsequent compilation, tests, controlled store checks, patch storage and any promotion. Import/deploy/graph-write gates remain closed.

## Graph-first gate and source confirmation

Bound discovery selected the registered candidate path and resolved it through LocalBackend to `samyama-graph-l3jvb3` (display name `samyama-graph`), storage `/root/.cache/gitnexus/vendor-upgrade-samyama`. Index recorded exact `17e55660...` at `2026-10-13T16:54:31.924Z`; independent `git rev-parse HEAD` confirmed the same full SHA. CLI `status --repo <candidate>` selected that slot. Its “source checkout unavailable” message describes symbol-only retention (`sourceAvailable=false`), not a missing candidate checkout; source was directly read and HEAD checked.

Before edits, upstream impacts reported:

| Target | Risk | Reach reported |
| --- | --- | --- |
| `VectorIndex.add` | MEDIUM | 7 direct, 1 indirect; Vector module |
| `VectorIndex.load_with_quantization` | LOW | 2 direct, 3 indirect |
| `VectorError` | UNKNOWN | No callers resolved, not treated as unused |
| `VectorIndexManager.add_vector` | HIGH, lower-bound | 5 direct, 1 indirect; 3 unresolved receiver sites |
| `weakly_connected_components` | LOW | 3 tests resolved; not a complete consumer inventory |

HIGH `add_vector` direct callers include `GraphStore.start_background_indexer_with_store`, `spawn_auto_embed`, persistence vector roundtrip and manager tests. Affected flows are `Start_background_indexer_with_store → IndexKey` and `Start_background_indexer_with_store → Name`. Work stopped before source edits; parent explicitly reported the HIGH warning to the user and then authorized this scope.

Index limitations remain: FTS disabled, operator/planner above 512 KB skipped, index process extraction bounded, three `add_vector` receiver sites unresolved. Exact candidate sources confirmed the broader create/property/label/readback call sites plus giant query-operator and SDK WCC consumers. The UNKNOWN enum result was resolved for this addition by reading actual constructors, reexports, SDK string conversion and matches in candidate `src/`, `crates/`, `tests/`: no exhaustive `VectorError` match was found. Unknown is not low and no absent-edge safety claim was made.

Evidence: `vector-port-impact.json`, `vector-port-source-confirmation.json`. Read-only `detect_changes` after formatting bound the candidate worktree explicitly and returned 3 files, 42 previously indexed touched symbols, medium summary risk, one affected background-index flow; no partial/truncated flag. Newly added symbols are not in the pre-edit index; this result does not prove their call coverage. Saved `vector-port-detect-changes.json`.

## Required vector behavior

- Restored `VectorError::VectorConflict { node_id }` and `NodeNotFound { node_id }`.
- `add` validates dimensions first, checks identity by node ID, no-ops for equal stored vectors and returns conflict for a different vector without changing backend, persistence entries or exact buckets. Different nodes may share the same vector.
- Kept exact method names/signatures `VectorIndex::replace(&mut self, NodeId, &Vec<f32>)` and `VectorIndexManager::replace_vector(&self, label, property, NodeId, &Vec<f32>)` for the adapters.
- `replace` validates dimensions first, rejects absent nodes, and no-ops for equality. Changed replacement builds a new selected F32/F16 index, reinserts the ordered stored entries through the existing `add` path with the one replacement, and assigns the rebuilt index only after every insertion succeeds. There is no recursive replace, stored-slot pre-mutation, or manual synchronization of backend/storage/hash arrays.
- Rebuild uses existing `Self::build` (the same construction path as `with_quantization` and load), with the existing load sizing expression `(len + 10_000).max(100_000)`. Dimensions, metric and quantization come from the original index. The actual public constructor is `with_quantization`, not `new_with_quantization` in this upstream revision. No HNSW or threshold constant was changed.
- Manager replacement holds the existing per-index write lock and changes the object inside the same Arc. Name and embedding model bindings stay in the manager maps; the replacement does not recreate the manager index.
- A missing manager index now errors with `IndexError`, rather than retaining the old local silent-`Ok` gap. Missing-node/dimension errors propagate.

### Equality decision and unchanged defaults

F32 retains original Rust slice/value equality (including its existing signed-zero/NaN rules). F16 identity deliberately compares the **actual stored f16 bit pattern after rounding the supplied f32 vector**. Thus distinct f32 inputs that round to the same half-precision representation are equal for an F16 index. This is not an f32-equivalent identity promise. A dedicated source test distinguishes these cases.

`VectorIndex::new`, manager `create_index` and load defaults remain F32/`Quantization::None`. No fp16 activation, GPU/SIMD feature, distance implementation or quantization persistence-format change was made. Upstream backends still compute cosine despite the nominal metric metadata; tests checking preservation of `InnerProduct` metadata do not claim that metric has gained an implementation.

### Event and autoembed boundary

Repeated equal calls through manager `add_vector` are now harmless. A conflicting event/autoembed add remains an error, not an implicit sanctioned replacement. Several vendor graph event/readback sites still use `let _ = add_vector(...)` and therefore swallow that conflict; autoembed logs a failure. Those paths were deliberately not changed. Broader property/autoembed update compatibility and error propagation remain parent validation/review work, not results claimed here.

## WCC

Restored unions from both `successors` and `predecessors`, retaining the local tolerance for incoming-only/mixed CSR arrays. Documented that numeric union-root component IDs depend on node and edge traversal order. Tests compare sorted canonical node partitions and map membership, never fixed numeric root IDs.

## Unit tests added (not executed)

Index:

- `test_vector_index_add_is_idempotent_and_conflicts_fail_closed`: both F32/F16, equal and conflicting node re-adds, dimension-before-identity refusal, backend contents/exact buckets, distinct equal-vector nodes.
- `replacement_refuses_missing_nodes_and_wrong_dimensions_without_mutation`: both precisions; absent node; wrong dimensions for present/absent node; equal replacement; unchanged backend/hash/dump bytes.
- `replacement_rebuilds_both_search_paths_and_survives_dump_reload`: both precisions, sizes 3 and 160 (>128), deterministic power-of-two values, two equal-vector nodes before replacement, correct exact buckets afterwards, public search, explicit HNSW stored point IDs/values/counts, precision/storage exclusivity, preserved dimensions/metric, bincode stored contents and reload.
- `fp16_identity_compares_the_stored_quantized_representation`: unequal f32 inputs that round equal in F16 versus conflict + sanctioned replacement in default F32.

Manager:

- `repeated_vector_events_are_idempotent_and_conflicts_need_explicit_replacement`: no auto/network; repeated manager calls, conflict refusal, sanctioned and equal replacements, old-value replay refusal, unchanged Arc/name/model/dimensions/metric/quantization.
- `replacement_refuses_missing_indexes_nodes_and_wrong_dimensions`: missing-index gap fixed, missing-node error, dimension pre-mutation.

WCC:

- Replaced empty `test_wcc` placeholder with consistent/outgoing-only/incoming-only canonical partition and map-membership cases.
- `wcc_includes_edges_present_in_only_one_csr_array`: disjoint incoming/outgoing-only edges, isolated node, canonical partition.

Fixtures use fixed IDs and values, no network or random-generated corpus. The upstream HNSW backend still chooses randomized levels internally; assertions inspect stored points and exact buckets/search paths, not approximate recall or unstable layer layout.

## Checks actually run

| Check | Result |
| --- | --- |
| Native `rustfmt --edition 2021 --config skip_children=true <three scoped files>` | exit 0 |
| Native `rustfmt --edition 2021 --config skip_children=true --check <three scoped files>` | exit 0 |
| `git diff --check` | exit 0 |
| Candidate source scope/status | Only three tracked scoped sources modified; pre-existing `.cargo/` untracked |
| Bound LocalBackend `detect_changes(scope=all, worktree=<candidate>)` | exit 0, no partial/truncated flag; limits above |

Native formatting was the last source-mutating action. Rustfmt expanded existing upstream formatting in the same three files; unchanged SCC/search/manager routines were reformatted, not semantically adapted.

## Exact patch and hashes

Exact pristine-candidate diff: `/tmp/vendor-upgrade-audit/vector-wcc-port.patch` (39482 bytes).

SHA256: `e19e9cf7d35595c468d4974d949c8fe63c4268936e659a17572d073a7a9f0643`.

Diff stat:

```text
 crates/samyama-graph-algorithms/src/community.rs | 125 ++++++--
 src/vector/index.rs                              | 373 +++++++++++++++++++++--
 src/vector/manager.rs                            | 162 +++++++++-
 3 files changed, 605 insertions(+), 55 deletions(-)
```

Final scoped source hashes:

- `src/vector/index.rs`: `b8f8d219fe367b8942ae3005b5f1166b025cce23990e1078114adfd3fa01075f`
- `src/vector/manager.rs`: `69000b757bf3fa97e3606328b0d89383ee187bd2a7a96f0bbc8c5bed2f67bcb6`
- `crates/samyama-graph-algorithms/src/community.rs`: `1561bdd71e14adacf9511ce30d8e2e31e765ffbe1e94b90cb6886329b8900b50`

## Disk and constants

Before work free: 27377471488 bytes (25.497 GiB). After source edits, formatter, graph review and patch capture free: 26899685376 bytes (25.052 GiB). Both exceed the 15 GiB floor. No target/build output was created. Notes and patch are small audit files only.

No numeric constants, feature defaults, dependency/config entries, import/deploy gates or production data changed. Assumptions: candidate originates at exact audited SHA; manager serialization remains the existing locking contract; f16 equality is the stored quantized representation only; WCC numeric roots are not stable IDs.
