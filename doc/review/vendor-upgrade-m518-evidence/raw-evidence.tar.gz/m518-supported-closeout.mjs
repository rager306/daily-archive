import {readFileSync} from 'node:fs';
const root='/root/.gsd/agent/extensions/gsd';
const base='/root/daily-archive';
const mid='M518-i56mt5';
const dbw=await import(`${root}/db-workspace.js`);
const db=await import(`${root}/gsd-db.js`);
const wf=await import(`${root}/tools/workflow-tool-executors.js`);
const {internalExecutionInvocation}=await import(`${root}/execution-invocation.js`);
const {internalPlanningInvocation}=await import(`${root}/planning-invocation.js`);
const input=JSON.parse(readFileSync(process.argv[2],'utf8'));
const opened=dbw.openExistingWorkflowDatabase(base);
if(!opened.ok)throw Error(JSON.stringify(opened));
function checked(r){
 console.log(JSON.stringify(r));
 if(r.isError||r.details?.superseded||r.details?.current===false||r.details?.stale)throw Error(JSON.stringify(r));
 return r;
}
if(input.operation==='summaries'){
 for(const entry of input.summaries)checked(await wf.executeSummarySave(entry,base,internalPlanningInvocation()));
}else if(input.operation==='cancel-external-attemptless-slice'){
 checked(await wf.executeSkipSlice({milestoneId:mid,sliceId:'S01',reason:input.reason},base,internalExecutionInvocation(input.invocationKey)));
}else if(input.operation==='gates'){
 for(const entry of input.gates)checked(await wf.executeSaveGateResult(entry,base,internalPlanningInvocation()));
 console.log(JSON.stringify({pending:db.getPendingGates(mid,'S01'),saved:db.getGateResults(mid,'S01')}));
}else if(input.operation==='validate'){
 checked(await wf.executeValidateMilestone(input.params,base,{invocation:internalExecutionInvocation(input.invocationKey)}));
}else if(input.operation==='complete'){
 const {checkCloseoutConsistencyGate}=await import(`${root}/closeout-consistency-gate.js`);
 const check=checkCloseoutConsistencyGate(mid,{allowOpenMilestone:true,artifactBasePath:base,readOnly:true});
 console.log(JSON.stringify({consistency:check}));
 if(!check.ok)throw Error(JSON.stringify(check));
 checked(await wf.executeCompleteMilestone(input.params,base,internalExecutionInvocation(input.invocationKey)));
}else throw Error('unsupported operation');
console.log(JSON.stringify({kind:'current-post-operation-readout',fence:db.readDomainOperationFence(),milestone:db.getMilestone(mid),slices:db.getMilestoneSlices(mid).map(s=>({id:s.id,status:s.status,tasks:db.getSliceTasks(mid,s.id).map(t=>({id:t.id,status:t.status})),pending:db.getPendingGates(mid,s.id)}))}));
dbw.checkpointWorkflowDatabase();
dbw.closeWorkflowDatabase();
