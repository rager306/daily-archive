# Samyama vector and algorithms upgrade audit — read-only, source only

## Revisions and limits

- Vendor repository: `/root/vendor-source/samyama-graph`.
- Upstream base: `4ede0b428ca5dfcffdb3a827fc913afca2f020b8` (1.7.0).
- Current committed vendor HEAD: `fd45131b3e1d3e58e8a6ff1ee7618d872477e79d`.
- Target main: `17e55660ef90bc177ac9b55a1a22a9d39b41aa0f`.
- Target release: v1.11.0, `4c99eb364fc919366e60b268b611390518b63566`.
- Every target comparison used `git show`, `git diff`, or `git log` with the exact SHA. The dirty checkout was read only to identify runtime differences; it was not substituted for either target.
- Main and v1.11.0 have **no difference in** `src/vector/`, `src/algo/`, `crates/samyama-graph-algorithms/`, `Cargo.toml`, or `Cargo.lock` at these revisions. Selecting the tag instead of main does not avoid any finding below.
- No checkout, merge, reset, edit, build, cargo command, test execution, benchmark, clean, push, or live-store access occurred. Only `/tmp/vendor-upgrade-audit/` notes were created. No constants were changed.

## Decision summary

**Not a drop-in upgrade.** The used algorithms' data shape remains compatible, but both required local vector changes are absent upstream. A pristine target loses a method currently called by `kg-storage` and loses duplicate rejection. The vector implementation has been reorganized enough that the local patches need a semantic port.

| Finding | Impact |
|---|---|
| `VectorIndexManager::replace_vector` and `VectorIndex::replace` are absent in both targets | Source-level compile blocker at `daily-archive/crates/kg-storage/src/samyama_adapter.rs:486–497`; no build was run |
| `VectorError::VectorConflict`/`NodeNotFound` and the duplicate-node guard are absent | Replaying the same node/vector appends another stored entry; adding a different vector for the same node does not refuse it. This breaks the local explicit-replacement contract |
| Dirty WCC adds a predecessor union loop; neither target has it | Membership is unchanged for consistent outgoing/incoming CSR, but incoming-only CSR changes behavior and numeric component IDs can change even on consistent views |
| `GraphView`, algorithm `NodeId`, CPU PageRank, WCC/SCC result maps remain compatible | The current DA analytics path projects through `kg_storage::adapter::graph_view_from`; it does not call vendor `build_view` directly |
| Dijkstra, MST, PCA and directed LCC change outside current direct DA usage | Do not assume the whole algorithms crate is API/semantics compatible merely because PR/WCC are compatible |
| HNSW changes 0.2.1 → 0.3.4; fp16 and exact-match search are added | Preserve duplicate/replace behavior across both new backends and the new exact-match lookup. SIMD is not enabled automatically |

## Current daily-archive use and graph evidence

The current root manifest points at this vendor checkout (`Cargo.toml:64–66`). `samyama-graph-algorithms` has `default-features = false`; `kg-storage` gates its adapter behind `algorithms`, and `kg-algorithms` uses the same type under `solver`/`ppr`. No direct `hnsw_rs::`/`anndists::` references were found under current `crates/**/*.rs`.

Graph-first discovery was attempted using the explicitly bound `daily-archive` repository. Initially the index was behind one commit. The centrally refreshed index then reported HEAD `eda16b4a496d8c177d2d6b1ab57e5feccf52a4cd`, indexed at `2026-10-13T16:24:38.566Z`, without a stale warning. Both old and refreshed `query` calls returned empty because **FTS is disabled**; emptiness was not interpreted as no usage or safety. Named `context` resolves the current adapter and helper:

- `SamyamaGraphStore.replace_vector` implements `DirectGraphStore.replace_vector`, but its incoming graph is a lower bound due to interface dispatch (5 implementations, 1 interface-level consumer).
- `write_node_embedding` context names `extraction::write_entity_embedding`, `IngestUseCase::materialize_parsed_with_context`, and helper tests as callers; it calls the add and replace port methods.
- Current source additionally confirms `scheduler_executors.rs:385–389` calls replace for changed Paper vectors.
- `graph_view_from` context names `da-mcp::graph_rank`; current source also confirms CLI analytics and its tests. The index is not a substitute for these source confirmations.

Production algorithm calls found under `crates/`:

- `da-cli/src/analyze.rs:22,84,109,152`: PageRank and WCC, reading `WccResult.components`.
- `da-mcp/src/tools.rs:591–618`: PageRank and WCC, reading `node_component`.
- `kg-storage/src/adapter.rs:16,39–150,183–322`: constructs CSR GraphView from its own port. It constructs out- and in-adjacency together, preserves sparse graph IDs, skips self-loops, and folds all-unit weights to `None`.
- `kg-algorithms/src/csr.rs:21,90,116`, `ppr.rs:19,80`, `view_algorithms.rs:22`: consume GraphView mappings, outgoing CSR and optional weights. Their PPR is RuVector ForwardPush, not the newly added vendor personalised PageRank.

No literal calls to vendor `samyama::algo`, `build_view`, `dijkstra`, `prim_mst`, `PcaConfig`, or LCC were found in current `crates/**/*.rs`. This scopes direct usage; dynamically supplied Cypher can still call vendor procedures.

## Local vector patches: neither is upstream-equivalent

### `78b79a62107f3201f24bf30183216e61199e481a` — duplicate rejection

At current HEAD, `src/vector/index.rs:182–209`:

1. Dimension mismatch errors before mutation.
2. Search stored entries by **node ID**, not by vector bits.
3. Same node plus equal `Vec<f32>` is an `Ok(())` no-op.
4. Same node plus a different vector returns `VectorConflict { node_id }`, without appending or changing search state.
5. A new node may share a vector with another node; that is not a conflict.

The local source test is `test_vector_index_add_is_idempotent_and_conflicts_fail_closed`.

In both targets, `src/vector/index.rs:336–375` validates dimensions and then inserts/appends to the selected backend. It does not look up an existing node ID. `VectorError` at lines 56–78 has neither conflict nor node-not-found variant. This is **not absorbed** by the new `exact` hash map: `exact` groups vectors by bit pattern, not identity, and its value is a list of positions. It deliberately allows multiple nodes sharing a vector. `tests/vector_recall_floor.rs::two_nodes_with_the_same_vector_are_both_found_and_k_is_respected` tests two distinct IDs (7 and 1000), not repeated insertion of the same ID.

### `fd45131b3e1d3e58e8a6ff1ee7618d872477e79d` — explicit replacement

At current HEAD:

- `VectorIndex::replace`, `index.rs:216–237`: dimension check; missing node gives `NodeNotFound`; equal vector is a no-op; changed vector replaces its stored slot and rebuilds HNSW while preserving the node ID.
- `rebuild_hnsw`, `index.rs:239–248`: reconstructs from the stored list.
- `VectorIndexManager::replace_vector`, `manager.rs:78–92`: holds the same index write lock and calls replace.

The replacement commit added no dedicated vendor replacement test. Current DA has `kg-storage/src/mock.rs::replace_vector_swaps_same_node_and_is_idempotent`, but it exercises the mock, not the vendor replacement implementation.

The new targets have **no replacement method** in either type. `VectorIndexManager::rebuild_for_label` (`manager.rs:354–406`) is not an equivalent: it takes an entire supplied list, drops/rebuilds the index, skips bad vectors, and succeeds for an absent index. DA's port needs one-node replacement with an absent-node error. Replacing this call with ordinary `add_vector` is not safe: old vectors survive, duplicates enter persistence, and the application may stamp a fingerprint while search still sees old data.

### Port requirements if an upgrade is authorized later

The old physical representation (`hnsw` plus `stored_vectors`) was replaced by:

- `Backend::F32` / `Backend::F16` (`index.rs:232–235`),
- `stored_f32` / `stored_f16`,
- `exact: HashMap<u64, Vec<usize>>` (`index.rs:238–255`).

Therefore the two old changes cannot be treated as a blind replay of the old HNSW field/slot code. No cherry-pick/apply trial was performed; patch survival is a source assessment.

Required semantics to carry forward:

1. Retain distinct-node equal-vector support. The duplicate guard must be node keyed, not vector keyed.
2. Retain idempotent same-node/same-vector add and fail-closed same-node/different-vector add.
3. Retain explicit same-node replace, absent-node error, dimension validation before mutation, and equal-replace no-op.
4. Rebuild the chosen backend, storage entries **and exact buckets** together after a replacement. Mutating only the stored list or HNSW leaves the other search path stale; position-based hash entries must correspond to the rebuilt arrays.
5. Preserve current quantization, dimensions and metric metadata, plus manager name/model bindings. Do not rebuild through a path that silently resets fp16 to f32 or loses these bindings.
6. Define fp16 equality deliberately before exposing it to DA. The old contract compared supplied f32 values, while fp16 only retains rounded values. Two distinct f32 inputs can collapse to the same stored vector. DA defaults to `Quantization::None`, so retain that default during the first port rather than claiming f32-equivalent identity for quantized input.
7. A missing index must not silently claim successful replacement. The existing local manager actually returns `Ok(())` on a missing index; that is a known gap relative to the DA port's absent-vector clause. Upstream add now refuses a missing index (`manager.rs:174–199`). Do not accidentally preserve the local false-success gap as a required behavior.
8. Check normal property/index event replay separately. Upstream GraphStore routes vector-valued creation/property/label events through `add_vector` and ignores some returned errors (`store.rs:1586,1659,1716,6154,6586,6612,6619`). Replaying an identical event should be harmless; a conflicting vector must not become implicit sanctioned replacement. Broader vendor auto-embed/property-update flows cannot be assumed compatible with the restored fail-closed rule.

DA's contract at `kg-storage/src/traits.rs:118–128` requires same-ID replacement, idempotence and an error when no vector is stored. `da-application/src/embedding_write.rs:36–86` depends on explicit add-or-replace and stamps `embedding_sha256` only after write success. These are runtime requirements, not optional local conveniences.

## Vector changes worth keeping, without performance claims

Pinned target source introduces:

- Cosine clamping into [0,2] (`index.rs:101–133`), protecting the HNSW metric against rounding artifacts.
- Exact linear search for index size ≤128 (`index.rs:400–403`), and exact fallback on HNSW panic or empty answer.
- Bit-pattern lookup that merges stored-vector matches into large-index HNSW results (`index.rs:446–493`), so a stored vector finds itself even if HNSW connectivity misses it.
- `Quantization::{None,Fp16}`, new construction/load APIs and typed half-precision backends. Arithmetic accumulates in f32; the fp16 query is rounded before search. The raw vector dump remains bincode `Vec<StoredVector>` containing f32 values, widening rounded fp16 on output (`index.rs:500–509,560–612`). This does not restore precision already lost by quantization.
- Manager index names, embedding model bindings, definition export, all-index search, and label-aware filtered search.
- Adding to an absent manager index now returns `IndexError`; searching an absent manager index still returns an empty result.

`VectorIndex::new`, `add`, `search`, `dimensions`, `metric`, `len`, `is_empty`, `dump`, `load` and manager `create_index`, `get_index`, `add_vector`, `search` remain source-compatible signatures. Their behavior is not all unchanged.

Two qualifications:

- **Declared distance metrics remain nominal**: both old and target `VectorIndex` use cosine backends regardless of the retained L2/InnerProduct `metric` field. The enum alone is not evidence those metrics were implemented by the upgrade. DA maps its L2/Dot options to that field.
- The new `GraphStore::vector_search` filters removed/deleted labels and widens fetches, but DA's low-level adapter calls `store.vector_index.search` directly (`samyama_adapter.rs:184,344,510`), which does not use that label filter. Do not claim DA inherits the new filtered-query guarantee without changing its call path.

## HNSW, SIMD and features

Manifest and lockfile changes at the exact target:

- `hnsw_rs = "0.2.1"` → `"0.3.4"`; lockfile resolves 0.3.4 and adds `anndists` 0.1.5. The upstream source test describes removal of the `skiplist` dependency as the RUSTSEC-2026-0300 fix. That is an upstream claim backed by the lockfile dependency removal, not a security scan run by this audit.
- The declared version is a caret requirement, not `=0.3.4`; the consuming DA lockfile will need an intentional dependency resolution later. DA's current lock contains only hnsw_rs 0.2.1. Cached 0.3.5 is present but was **not** substituted for the pinned target's lockfile version in this audit.
- The already-cached registry sources show hnsw_rs 0.3.4 and anndists 0.1.5 use Rust edition 2024. DA currently pins Rust 1.99.0; no compiler invocation was made.
- hnsw_rs 0.3.4 keeps `default = []`, forwarding `simdeez_f` and `stdsimd` to anndists. `stdsimd` activates `feature(portable_simd)` and needs nightly. Samyama's target manifest requests plain hnsw_rs, exposes no SIMD-forwarding feature, and continues to implement its own scalar `CosineDistance`/`CosineDistanceF16` loops. Thus upgrading does **not** enable SIMD for this distance. Enabling anndists' built-in distance features would not automatically vectorize Samyama's custom implementation.
- Algorithm crate defaults remain empty; `gpu`, `cuda`, `serde` remain opt-in. GPU dispatch becomes backend-sensitive: default threshold 1,000 for CUDA, 1,000,000 for Metal; `SAMYAMA_GPU_MIN_NODES` still overrides it, and runtime initialization is avoided for too-small graphs. DA's observed defaults do not enable GPU.
- Samyama default features change from `[]` to `["mimalloc"]`. DA's direct `samyama` edges currently allow defaults, so the dependency can be compiled. However the library only names the allocator (`src/allocator.rs`); vendor `src/main.rs` and benchmark binaries install it. DA embedded use does not acquire a global allocator merely by importing the library. SDK's new edge disables Samyama defaults, but that does not cancel DA's other default-enabled edges.
- fp16 is a runtime/DDL option, **not a cargo feature**. `new`/`create_index` remain unquantized. `int8`/unsupported quantization options are refused, not silently enabled.

## Algorithms: stable used surface and changed wider surface

### Stable shape used by DA

`crates/samyama-graph-algorithms/src/common.rs:8–33,87–135` still defines algorithm `NodeId = u64` and the same eight public GraphView fields:

`node_count`, `index_to_node`, `node_to_index`, `out_offsets`, `out_targets`, `in_offsets`, `in_sources`, `weights: Option<Vec<f64>>`.

CSR uses dense indices internally and maps back to sparse external IDs. `from_adjacency_list`, degree/neighbour methods and weight slicing keep their signatures. The only change in this baseline module is additive `first_negative_weight`. No new CSR validation is added to `from_adjacency_list`.

CPU `page_rank(&GraphView, PageRankConfig) -> HashMap<u64,f64>`, the config fields/defaults, and CPU numeric implementation are unchanged. It remains unweighted; weights in CSR do not make PR weighted. WCC/SCC keep `components: HashMap<usize,Vec<u64>>` and `node_component: HashMap<u64,usize>`.

### Dirty WCC change — explicit disposition needed

The dirty runtime `community.rs:58–72` unions both `successors(u)` and `predecessors(u)`. Committed HEAD and both targets (`community.rs:59–69`) union only successors. The target's conventions document correctly notes that scanning **all** outgoing edges is enough to union an undirected component: each directed edge `(u,v)` already unions its endpoints once.

- For a consistent GraphView whose incoming array is the reverse of its outgoing array, the dirty predecessor loop is **redundant for component membership**. DA's production `graph_view_from` and subgraph adapter construct both sides from one edge pass, so this path does not need the extra scan.
- For an incoming-only or mismatched GraphView, the dirty implementation uses the union of edges in both arrays; upstream ignores the incoming-only edges. `from_adjacency_list` allows that representation without validation. An incoming-only two-node view with no outgoing edge is connected under dirty code and isolated under upstream. No current DA production projection of this form was found.
- Even for consistent CSR, union order changes the **numeric union-find root IDs**. Source reasoning example: dense indexes 0,1,2 with outgoing edges `2->0` and `2->1`. Successor-only unions start at node 2 and retain root 2. Dirty code reaches the predecessor of node 0 first and retains root 0. Membership is identical, exposed component IDs are not. This is a source derivation, not a runtime result.
- `da analyze` prints only count/largest size, so this root renumbering does not change that output. MCP `graph_rank` exposes component IDs and sizes. Neither upstream root IDs nor old dirty root IDs should be promised stable across rebuilding/index assignment.

Recommendation: record the dirty patch independently. Removing it can be justified for the production consistent-CSR contract, not as "upstream absorbed the patch". If incoming-only tolerance is intentional, preserve and test it. Compare canonical node partitions rather than literal root IDs when evaluating equivalence.

### Vendor `samyama::algo::build_view`

Its four-argument signature still returns GraphView (`src/algo/mod.rs:44–51`). It now delegates to a shared implementation, sorts node IDs (`:114`), publicly re-exports GraphView, and adds `build_temporal_view` that captures timestamps aligned with out-target slots in the same pass. Parallel-edge timestamps are not reconstructed by endpoint pair.

Independently, target `GraphStore::get_nodes_by_label` now walks bitsets in ascending ID order rather than hash-set iteration. That also changes the ordering seen by DA's own projection, which does not sort its full-label result locally. It improves determinism but may renumber WCC roots. Subgraph projection already sorts locally.

The new temporal adapter is not DA's temporal edge resolver and must not be treated as a drop-in scientific temporal convention. Its `edge_time` directly reads integer, DateTime, date/local/zoned temporal variants or falls back to `created_at`; unit discipline would need a separate review before adopting it.

### Wider public API/semantic breaks

- `dijkstra` (`pathfinding.rs:106–140`) changes from `Option<PathResult>` to `Result<Option<PathResult>, NegativeWeight>` and refuses a negative weight anywhere in the view instead of silently skipping it. `bfs`, `bfs_all_shortest_paths`, and the PathResult fields remain unchanged.
- `MSTResult` (`mst.rs:9–18`) adds required `components: usize`. Struct literals/exhaustive destructuring without `..` must change. `prim_mst` now spans **all** components as a forest, rather than only the component containing dense index 0; totals/edges change for disconnected graphs. Equal weights have explicit index tie-breaking.
- `PcaConfig` (`pca.rs:44–87`) adds required `seed: u64`; exhaustive struct literals must change. The default seed is fixed (`0x5A_4D_59_4D_41`), and randomized PCA above Auto's 500-row threshold uses it. Components are not sign-canonicalized, and randomized orthogonality remains approximate.
- `edmonds_karp(source == sink)` now returns `None` instead of looping indefinitely; return type stays `Option<FlowResult>`.
- Directed LCC switches to Fagiolo's reciprocal-aware definition and adds explicit `DirectedLcc::Ldbc` via `local_clustering_coefficient_with`. Default undirected entry point/signature survives. Directed numeric expectations change.
- Numerous centrality/link-prediction/community/path/temporal and FastRP/node2vec exports are additive. Their existence does not grant automatic compatibility with DA's weight, direction, provenance or graph-write restrictions. Graph embedding Cypher procedures write properties; D127/import/deploy locks stay closed.

The upstream `docs/ALGORITHM-CONVENTIONS.md` still describes old MST and direct weighted-path behavior in some rows despite newer bodies/tests. Use actual source/tests above as the current contract; do not rely on those stale rows for a compatibility waiver.

## Source tests inspected — **none run**

Relevant target tests already present, candidates for a later authorized validation:

- `src/vector/index.rs`: `dimension_mismatch_is_reported_on_add_and_search`, `large_indexes_search_the_graph_and_find_stored_vectors_exactly`, `fp16_index_stores_half_the_bytes_and_searches_exactly_when_small`, `a_quantized_dump_reloads_at_either_precision`, `test_vector_index_persistence`.
- `src/vector/manager.rs`: `adding_to_a_missing_index_stores_nothing_and_searching_it_finds_nothing`, `rebuild_skips_mismatched_vectors_and_ignores_unknown_indexes`, `dump_and_load_round_trip_model_ids`.
- `tests/vector_recall_floor.rs`: `hnsw_recall_stays_above_the_floor`, `a_vector_in_the_index_is_its_own_nearest_neighbour`, `a_vector_in_a_quantized_index_is_its_own_nearest_neighbour`, `two_nodes_with_the_same_vector_are_both_found_and_k_is_respected`.
- `tests/vector_quantization.rs`: `fp16_halves_the_bytes_the_index_holds`, `fp16_recall_tracks_full_precision_on_the_same_corpus`, `the_ddl_option_reaches_the_index_and_survives_the_backfill`, `an_unrecognised_quantization_is_refused_rather_than_defaulted`, `a_quantized_index_round_trips_through_the_unchanged_file_format`.
- `src/algo/algo_cov_tests.rs`: `build_view_filters_by_label_and_edge_type_and_reads_weights`, `temporal_view_aligns_times_with_targets_and_reads_every_time_type`, `edge_time_falls_back_to_created_at`.
- `tests/a_label_scan_is_ascending_from_either_method.rs`: `both_methods_are_ascending`, `the_two_methods_agree_with_each_other`, `a_limited_scan_is_a_prefix_of_the_unlimited_one`.
- `tests/negative_weight_refusal.rs`: `the_algorithm_itself_refuses_rather_than_skipping`, `the_algorithm_answers_once_the_negative_edge_is_gone`, `weighted_calls_refuse_a_negative_weight_and_name_the_one_that_handles_it`.
- Algorithms source: `community::tests::test_wcc`, `pagerank::tests::test_pagerank_scores_sum_to_one`, `mst::tests::a_disconnected_graph_spans_as_a_forest`, `mst::tests::equal_weights_break_the_same_way_every_time`, `flow::tests::max_flow_to_itself_terminates`, PCA `randomized_solver_gives_the_same_answer_twice` and `a_different_seed_draws_a_different_projection`.

Existing DA tests relevant to used contracts:

- `kg-storage/tests/algo_adapter.rs`: `test_graph_view_from_citation_graph`, `test_pagerank_cited_paper_ranks_highest`, `test_wcc_connected_graph`, `test_wcc_two_isolated_papers`, `test_weighted_graph_preserves_edge_weights`.
- `kg-storage/tests/subgraph_adapter.rs`: `same_inputs_twice_yield_identical_sorted_indexes`, `weight_property_preserves_mock_float_weights`.
- `kg-algorithms/src/csr.rs`: `weighted_directed_export_matches_outgoing_csr`, `missing_weights_with_nodes_returns_err`, `materialize_unit_weights_enables_export_after_fold`; corresponding PPR seed/missing-seed/unit-weight tests.
- `kg-storage/src/mock.rs`: `replace_vector_swaps_same_node_and_is_idempotent`.
- `da-application/src/embedding_write.rs`: `add_replace_noop_semantics_unchanged`, `dual_write_failure_is_err_not_fake_replaced`, `failed_sha_stamp_is_err_not_fake_added`.
- `da-application/tests/batch_ingest_test.rs`: `changed_embedding_replaces_via_sanctioned_upsert`.

**Coverage gap:** DA's shared `kg-storage/src/contract.rs::graph_store_contract_suite` does not currently check vector add/replacement. Passing `contract_samyama.rs` alone would not demonstrate preservation of either local vector patch. The required later tests must exercise the actual vendor/embedded adapter: identical re-add, conflicting re-add without mutation, explicit replacement searchable under the same ID, no old/duplicate entry after dump/load, absent-node/index and dimension refusals, repeated equal replace, both small exact-search and >128 HNSW/exact-bucket paths. If fp16 is retained, add separate precision/equality cases and rebuild/exact-bucket checks. These are proposed checks, not executed evidence.

## Supporting audit notes

- `/tmp/vendor-upgrade-audit/samyama-vector-local-patches.txt`: exact local commit patches.
- `/tmp/vendor-upgrade-audit/samyama-existing-algorithm-api.diff`: base → target changes for algorithm files that existed at the base.
- `/tmp/vendor-upgrade-audit/samyama-vector-algorithms-graph.json`: initial graph query/context evidence and freshness caveat.
- `/tmp/vendor-upgrade-audit/samyama-vector-algorithms-graph-fresh.json`: centrally refreshed index metadata/context; FTS remains disabled.
