# Samyama latest-upstream prebuild audit

**Decision:** use exact audited `origin/main` as the candidate, but **do not update the shared dirty checkout or build a pristine upstream candidate as if it were compatible**. Required local vector contracts are absent upstream. Daily-archive needs explicit value, property-getter, and snapshot-identity adaptations. General RocksDB in-place upgrade/downgrade is unsafe on the audited binary format.

This is a source review, not tested compatibility. No cargo, compiler, test, benchmark, store open, checkout, merge, reset, clean or push was run. Only `git fetch origin --tags` updated remote objects/refs; repository working trees were not changed. Native `rustfmt --emit stdout` parsed **temporary copies** solely to classify existing dirty changes. No constants or permission gates were changed. No speed gain is claimed.

## 1. Exact revisions and divergence

| Item | Exact revision |
|---|---|
| Shared vendor committed HEAD | `fd45131b3e1d3e58e8a6ff1ee7618d872477e79d` (package 1.7.0) |
| Current upstream default HEAD | `17e55660ef90bc177ac9b55a1a22a9d39b41aa0f` (`main`, 2026-10-09) |
| Latest stable release/tag | `v1.11.0` → `4c99eb364fc919366e60b268b611390518b63566` (2026-10-05) |
| Previous release | `v1.10.0` → `42b08c3fe96de59c272285eb32aa2d9ead78e9e8` |
| Merge base | `4ede0b428ca5dfcffdb3a827fc913afca2f020b8` |
| Artifact tag kg-snapshots-v10 | `f36b6ca98351a76a6d5d8f3cd7aa5e68e951f295` |
| Artifact tag kg-snapshots-v9 | `ae5ca7e1054b207b11ebcd87776a54c3fbdc86c1` |

Remote `HEAD` is `refs/heads/main`, confirmed by `ls-remote --symref`. The GitHub releases/latest read-only API also names v1.11.0, non-prerelease. Vendor HEAD and main diverged: **2 local-only commits / 874 upstream-only commits**. Fast-forward is impossible. Main is 23 commits beyond the release; manifests/lock/vector/algorithms/SDK core are the same in those two candidate revisions. Main adds relevant edge-count semantics and dedup merge-shape reporting, not a new snapshot format generation. Choosing the tag does not avoid the compatibility blockers.

The exact HEAD→main inventory contains 1,011 changed/renamed/deleted file entries, including 187 entries in dependency/API/storage/algorithm scopes. Full commit and file inventories are saved beside this report; the JSON includes the relevant entries.

## 2. Preserve local work, including the real semantic changes

Status was unchanged before/after audit: **249 tracked modifications**, plus `.cargo/`, `.claude/`, `AGENTS.md` untracked (8 files). Both local commits and the entire tracked dirty patch are copied as audit data to `/tmp/vendor-upgrade-audit/`.

A Rust parser/formatter comparison avoids the misleading `git diff -w` size:

- 247 modified Rust files were copied from exact HEAD and the dirty tree into `/tmp`, parsed with the same `rustfmt 1.10.0-stable`, edition 2021, `skip_children=true`, `--emit stdout`.
- **245 are byte-identical after canonical formatting.**
- `src/lib.rs` has only re-export ordering and blank-line changes.
- **`crates/samyama-graph-algorithms/src/community.rs` is semantic:** WCC additionally unions every predecessor. It is absent in latest main and release.
- Cargo.toml adds local dev profile/cache settings (`opt-level=0`, dependency `incremental=false`); CLAUDE.md adds GitNexus instructions.
- The untracked system RocksDB config must be preserved. Agent instructions/skills must not be discarded merely because untracked.

Local-only commits are load-bearing:

1. `78b79a62107f3201f24bf30183216e61199e481a`: equal re-add for the same node is idempotent; conflicting re-add is refused.
2. `fd45131b3e1d3e58e8a6ff1ee7618d872477e79d`: explicit vector replacement preserves node ID, is idempotent when equal, rejects absent node, rebuilds HNSW.

Neither contract is absorbed upstream. Port semantically, not by assuming clean cherry-picks through the new fp16/index-manager implementation. WCC predecessor scanning is redundant for membership on consistent CSR, but supports incoming-only CSR and can change numeric component-root IDs even on consistent CSR. Preserve the patch or record an explicit tested disposition; compare canonical partitions, not raw union roots. Do not silently remove it.

## 3. Current daily-archive surface and graph-analysis limits

Reviewed current daily-archive `HEAD eda16b4a496d8c177d2d6b1ab57e5feccf52a4cd`, current Cargo manifests/lock and ADR-040, not old audits. Absolute path edges exist in root, da-adapters and da-mcp manifests; simply copying the consumer repo will otherwise still build the shared dirty vendor.

- **Scientific KG:** `kg-storage::SamyamaGraphStore` directly wraps `GraphStore` + `QueryEngine`; it is in-memory and refuses nonempty `DA_GRAPH_DATA_PATH`.
- **Real durable consumer:** `da-adapters::SamyamaJobLedger` uses `PersistenceManager` / RocksDB in its isolated operational tenant. It stores job state/events/spec as JSON inside `PropertyValue::String`. Do not summarize daily-archive as having no persistence.
- **RESP:** production `da serve-graph` is the project's bounded `kg-storage::ReadOnlyServer`, not vendor `RespServer`. It denies mutation/admin commands and preloads explicit `.sgsnap` into process memory. Vendor RESP remains in a direct smoke test.
- **SDK:** samyama-sdk is declared as a dependency but no direct `samyama_sdk::` references were found in current `crates/**/*.rs`. Its trait surface is reviewed, but not the main current runtime path.
- **Analytics:** own `graph_view_from` / subgraph projection produces vendor GraphView and runs PageRank/WCC/PPR export. No direct vendor `build_view` call was found in current crates.

Graph-first query/context/impact was attempted. Initial daily index was 1 commit stale; vendor index was at the common base, not current code. Root's refreshed daily index now matches eda16b4a4. FTS is disabled, so concept queries remain empty. SamyamaGraphStore symbol impact is **UNKNOWN/lower-bound** because GraphStore/DirectGraphStore interface dispatch leaves unresolved concrete callers; zero is not safety. A fresh File impact returns LOW for one import edge, but File lacks symbol process/module axes and cannot waive the dispatch gap. Source caller confirmation is required. Supporting graph evidence is saved; the vector note includes current embedding-write callers resolved by named context.

ADR-040 remains binding: Samyama sole KG/vector/persistence authority, RuVector agent brain, import_eligible=false. A vendor update does not authorize graph import, deploy, new LLM behavior, new DB or optimizer adoption.

## 4. Concrete blockers and required adaptations

### A. Missing required vector method and duplicate semantics — compile and behavior blocker

Main/tag lack `VectorIndex::replace`, `VectorIndexManager::replace_vector`, `VectorError::VectorConflict`, `VectorError::NodeNotFound`. Current `kg-storage/src/samyama_adapter.rs:486–497` calls `replace_vector`; pristine latest source cannot supply it. Upstream `add` appends duplicate IDs instead of honoring local idempotence/conflict semantics.

The latest implementation has separate F32/F16 HNSW/vector backends, exact-match buckets and small-index exact search. Replacement must update the backing vectors, index and exact buckets consistently, without retaining the old entry. Compare at small exact-search and larger HNSW thresholds; also persist/reload the result. No test was run.

### B. New enum cases — compile blocker, do not discard values

Current adapter exhaustively matches `Value` and `PropertyValue` (`samyama_adapter.rs:235–281`). Latest:

- `Value::Node` and `Edge` box payloads; `Value::List(Vec<Value>)` and `Map(BTreeMap<String,Value>)` are added.
- `PropertyValue` adds Date, LocalTime, Time, LocalDateTime, ZonedDateTime.
- `RecordBatch` adds `plan_hash: Option<u64>`; current consumer does not build a literal so that field alone is not a blocker.

Implement recursive list/map conversion and deliberate temporal rendering. No wildcard-to-null fallback. Latest `PropertyValue::to_json` renders new temporals to ISO strings while preserving old DateTime numeric output and duration object shape; it is a source-backed starting point, not a license to change the public wire contract silently. Query `Value` is only Debug+Clone, not serde; its enum changes are API changes, not a second serialized disk format.

### C. Unchanged getter signatures hide an edge-property regression

Latest `set_edge_property` / `set_edge_property_sparse` writes **only edge_columns**, removing the row-map key (`src/graph/store.rs:2381–2409,3205–3234`). Current adapter string/float getters still read only `get_edge_properties` sparse row map (`samyama_adapter.rs:669–681,709–722`). New edge weights/properties can therefore read as missing. Use audited column-first `edge_property(&self,EdgeId,&str)->Option<PropertyValue>` (`store.rs:6763–6772`) or a deliberately equivalent resolver. Node resolver should also follow upstream column-first `node_property`, not assume row-first precedence is still authoritative.

Core GraphStore create/read/set signatures and QueryEngine `execute` / `execute_mut` signatures stay. `get_node_at_version` changes Option<&Node>→Option<Node>, with no direct current consumer found. Exact declarations and enum sources are in `samyama-used-api.json`.
Latest canonical getters, from exact main `src/graph/store.rs:6751–6779`:

```rust
pub fn edge_properties_merged(&self, id: EdgeId) -> PropertyMap;
pub fn edge_property(&self, id: EdgeId, key: &str) -> Option<PropertyValue>;
pub fn node_property(&self, id: NodeId, key: &str) -> Option<PropertyValue>;
```

Each single-property getter checks the column first, then the legacy row; merged getters overlay column values on row-map values. `get_edge_properties(&self,EdgeId)->Option<&PropertyMap>` remains only the sparse map. Never infer merged authority from that unchanged signature.


### D. Latest export breaks strict snapshot fingerprints — runtime identity blocker

Actual `.sgsnap` header version remains **2** (readers accept 1/2). Latest `export_tenant` always writes a `t:"i"` index catalog immediately after the header, even empty, and may write `t:"h"` hierarchy declarations (`snapshot/mod.rs:185–213`). Current `kg-storage::fingerprint_snapshot` accepts **only n/e** records and rejects everything else (`snapshot_identity.rs:170–194`). Every newly exported snapshot would be rejected by DA.IDENTITY/evidence validation despite a supported header version.

Add explicit validation for catalog/hierarchy records and define their place in the established semantic identity contract. Do not blanket-ignore unknown record types; do not silently change `sgsnap-vid-canonical-json.v1` or rewrite old evidence. Physical bytes will differ regardless; semantic graph identity must be compared separately. Encrypted snapshot bytes are not plain gzip and are not supported by the current identity/import path.

### E. Unversioned bincode PropertyValue is not generally forward/backward compatible

RocksDB StoredNode/StoredEdge still nest unversioned bincode PropertyMap bytes. Old PropertyValue slots 5–9 are Array, Map, Vector, Duration, Null; latest inserts five temporals there and moves old cases to slots 10–14. There is no legacy nested-value decoder/version marker on the audited storage reads. Wrong-value decoding is possible, not only a clean error. Keeping DateTime at ordinal4 protects only DateTime.

Do not open a general old RocksDB directory in latest in place. Use old-reader JSON `.sgsnap` export→fresh new store with typed semantic verification, or an explicit binary migration decoder. String-only job ledger uses unchanged ordinal0 and is a limited source-compatible subset, **not cross-version tested**. It still needs isolated-copy reopen/fence/events/ownership tests and byte-preserved rollback. Its current mutation path reads a materialized persisted Node via `PersistentStorage::get_node`, calls `Node::set_property` on that row, then explicitly `storage.put_node` + checkpoint. It does not call `GraphStore::set_node_property`, so the new column-only in-memory setter does **not** empty its cloned row map. Retain that direct-storage write; do not replace it with WAL-only update persistence.

Latest WAL adds marked length + CRC32 and decodes old XOR records. Old readers do not mask the new high-bit length and can try >2GiB allocation. Forward outer-WAL compatibility does not fix inner PropertyValue bytes. `recover` uses RocksDB, not logical-WAL replay; do not infer safety from WAL tests. No real directories were opened.

## 5. Dependency, native-link and feature changes

- Package versions all move 1.7.0→1.11.0, with workspace version inheritance (GPU formerly1.1.0).
- **RocksDB unchanged:** crate0.22.0 / librocksdb-sys0.16.0+8.10.0, lz4+zstd. Current configs point to system8.10.0; symlink/header match. This is not a required 11.x RocksDB rebuild or ABI change. Preserve those paths/constants.
- hnsw_rs0.2.1→0.3.4; latest lock removes skiplist/adds anndists. Manifest is a caret range, not =0.3.4, so a Git SHA pin alone does not pin all resolved dependencies. Freeze reviewed consumer lock after controlled resolution.
- Cached hnsw0.2.1 and0.3.4/0.3.5 all unconditionally expose identical no_mangle FFI symbols. Two versions in one final link unit remain a native duplicate-symbol hazard. Upgrading can align Samyama with RuVector's0.3 family, but cannot prove unification without actual root dependency resolution/link validation. Vendor workspace patches do not automatically apply to an external consumer. Keep standalone ruVLLM critic isolation until proved otherwise.
- No automatic SIMD benefit: hnsw default features empty; stdsimd needs nightly; Samyama custom scalar cosine implementation is not automatically vectorized by anndists features. fp16 is a runtime/DDL option, not enabled by Cargo defaults.
- GPU/CUDA remain opt-in; algorithm crate defaults empty. Do not enable GPU as part of this upgrade.
- Samyama defaults now include mimalloc; SDK disables defaults but direct DA edges re-enable by feature union. The library does **not** install a global allocator. The vendor binary/benches install it; DA embedded allocation policy does not change just by import.
- New always-on dependency trees include Arrow/Parquet53, chrono-tz, TLS, crypto, CSV/tempfile. lru0.12→0.18.
- Current DA lock chrono0.4.45; cached Arrow53.4.1's chrono constraint is >=0.4.34,<0.4.40 and upstream lock uses0.4.39. Resolve/review root lock deliberately rather than asserting a manifest-only drop-in. No dependency check was run.
- Upstream top-level manifest declares no MSRV. Cached upstream-lock manifests include1.88 floors (time, encoding_rs, ICU) and Docker pins1.90; actual DA toolchain is **1.99.0**, but advertised workspace rust-version1.85 is not proof the new tree supports1.85. Native compiled minimum is unverified.

## 6. QueryEngine, SDK, RESP, algorithms and persistence semantics to regress

Read/write entry signatures stay, but latest adds bound parameters, dialect options, operator row budgets, slow-query metrics, opt-in result caching, plan hash and write deadlines/statement rollback. Current plain `execute` does not auto-enable result cache. Use current graph tasks to compare semantic answers, not speed. Null property assignment now removes properties; unsupported map-inside-list values are refused. Index updates, frozen-edge deletion/reuse and restored property reads have upstream fixes. They are source changes, not measured project improvements.

Latest SamyamaClient trait is unchanged. EmbeddedClient is still in-memory; `persistence_manager()` constructs a separate manager and does not attach/recover/auto-save the client. Snapshot import appends/remaps into the target, not a complete replace/rollback; use a fresh restore store. SDK File::create export is not automatically atomic publication. Latest SDK recursively renders list/map entities, and current direct adapter wire conversion needs its own explicit handling.

Vendor RESP adds auth/roles/tenant admission, transaction/deadline handling, true write refusal for GRAPH.RO_QUERY and parameter bindings. Current DA bounded read plane is separate; do not replace it with vendor RESP or broaden the allowlist. Vendor direct smoke target can be checked separately.

Used GraphView fields, NodeId=u64, CPU PageRank and WCC result shapes remain stable. Broader exported API changes: Dijkstra returns Result<Option<PathResult>,NegativeWeight>; MST adds components and spans a forest; PCA config adds deterministic seed; directed LCC definition changes. These are not direct current DA calls. Preserve degree-count PPR semantics; CSR weights do not make PageRank/PPR weighted. Numeric component IDs may change with ascending label scans/reordered unions; canonical partitions are the right comparator.

Latest plain .sgsnap carries declarations/node timestamps/loss inventory but still loses edge timestamps/MVCC history, remaps IDs, trims strings and has downgrade losses for new temporals (old reader treats them as maps). kg-snapshots-v9/v10 and softwarev1.10/v1.11 are artifact/release labels, **not** runtime format numbers. Refer to the persistence note for raw-last-import vs merged graph, snapshot+post-write recovery, encrypted restart, non-durable import ack and fail-open server startup caveats. Those server paths are not automatically adopted by DA embedded upgrade.

## 7. Recommended pinned implementation strategy and later regression plan

1. Leave `/root/vendor-source/samyama-graph` byte-preserved. Create an **authorized isolated candidate** at exact main SHA, with an independently saved local patchset and separate target/store paths. Do not pull/rebase the dirty shared tree.
2. Preserve both vector patches and the WCC semantic overlay; port vector contracts through F32/F16/exact buckets and explicitly decide WCC behavior.
3. Rebind every absolute Samyama path only in a disposable DA copy; adapt value conversion, node/edge property resolution and snapshot identity. Review all lock/dependency changes before build. Keep D127 false and no production/store writes.
4. After explicit build authorization, run focused native checks, never cargo test --workspace. Commands below are a plan only; **none was run**:

```text
cargo check -p kg-storage --features samyama,algorithms
cargo test -p kg-storage --features samyama,algorithms --test contract_samyama
cargo test -p kg-storage --features algorithms --test algo_adapter
cargo test -p kg-storage --features algorithms --test ppr_export_compose
cargo test -p kg-algorithms --features ppr --lib
cargo test -p da-application --lib embedding_write
cargo test -p da-application --test batch_ingest_test
cargo test -p da-adapters --test parse_job_ledger_test
cargo test -p da-cli --test remote_read_plane_test
cargo test -p da-cli --lib graph_tasks
cargo test -p kg-storage --lib snapshot_identity
cargo test -p kg-storage --features samyama --test resp_server_smoke
```

Mock analytics tests alone do not test the new embedded edge property getters. Shared graph-store contract currently omits vector add/replace. Add focused embedded tests for duplicate/equal/conflicting vectors, sanctioned replace/idempotence/missing IDs/dimensions, persistence/rebuild and threshold paths; typed temporal + nested Value wire output; edge property roundtrip before/after snapshot; column-vs-row precedence; catalog/hierarchy identity and unknown-record refusal.

In isolated upstream candidate, relevant existing sources offer focused targets:

```text
cargo test -p samyama --test vector_recall_floor
cargo test -p samyama --test vector_quantization
cargo test -p samyama --test vector_query_test
cargo test -p samyama --test restored_readers
cargo test -p samyama --test columnar_holds_every_variant
cargo test -p samyama --test frozen_adjacency_after_delete
cargo test -p samyama --test snapshot_index_catalog
cargo test -p samyama --test snapshot_import_rollback
cargo test -p samyama --test snapshot_preserves_properties
cargo test -p samyama --test recovery_reads_rocksdb_alone
cargo test -p samyama --test wal_checksum
cargo test -p samyama --test wal_torn_tail
cargo test -p samyama-graph-algorithms --lib
```

These sources are not evidence of old-generation binary compatibility. Build a separate-old-writer/new-reader typed fixture handoff into stopped disposable stores; compare every variant/full value, independent canonical graph identity/queries and indexes. Add old→new String-only ledger reopen/fence/events and untouched old rollback-copy reopen. Do not rewrite committed evidence or run old WAL replay against unrestricted new marked frames.

Run fmt as final implementation action and project final gates only after adaptations/tests, per repository policy. No results are claimed here.

## Supporting files

- `samyama-upstream.json`: machine-readable audit, revisions, status, relevant changed files and risks.
- `samyama-used-api.json`: exact used signatures and current/latest enum blocks.
- `samyama-dirty-classification.json`: parser/formatter comparison and remaining semantic diff.
- `samyama-dirty-tracked.patch`, `samyama-local-commits.patch`: complete tracked overlays.
- `samyama-status.txt`, `samyama-untracked-manifest.json`: preservation inventory.
- `samyama-upstream-commits.txt`, `samyama-upstream-files.txt`, `samyama-release-to-main-*.txt`: full exact histories/inventories.
- `samyama-persistence.md`: detailed binary/snapshot/WAL/ledger/server caveats and source tests.
- `samyama-vector-algorithms.md`: vector semantic-port requirements, WCC disposition and stable/broken algorithm surfaces.
