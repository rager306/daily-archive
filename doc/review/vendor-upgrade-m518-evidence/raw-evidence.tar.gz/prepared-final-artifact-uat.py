from pathlib import Path
import ast, hashlib, json, re
root=Path('/root/daily-archive')
audit=Path('/tmp/vendor-upgrade-audit')
def load(name):
    return json.loads((audit/name).read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def passed(name):
    receipt=load(name)
    assert receipt['exit_code']==0, name
    assert receipt.get('timed_out') is not True, name
    assert receipt.get('aborted') is not True, name
    return receipt
binding=load('after-content-repair-pre-gate-source-binding.json')
assert len(binding['source_hashes'])==917
for name,expected in binding['source_hashes'].items():
    assert sha(Path(name))==expected, name
for name,expected in binding['patched_vendor_files'].items():
    assert sha(Path('/root/vendor-source/samyama-graph-m518-17e55660')/name)==expected, name
for name,expected in binding['frozen_protected_hashes'].items():
    assert sha(Path(name))==expected, name
capture_dir=audit/'full-architecture-after-content-repair-step-captures'
rows=[json.loads((capture_dir/f'{n:02}.json').read_text()) for n in range(1,24)]
assert [r['number'] for r in rows]==list(range(1,24))
module=ast.parse((root/'scripts/governor/__main__.py').read_text())
fn=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='architecture_gate_steps')
scope={'_ARCHITECTURE_STEP_TIMEOUT_S':3600}
exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'native gate DATA','exec'),scope)
expected=scope['architecture_gate_steps']()
assert len(expected)==23
for row,(name,argv,seconds) in zip(rows,expected):
    assert row['status']=='complete' and row['exit_code']==0 and not row['timed_out'], row
    assert row['argv']==argv and row['timeout_seconds']==seconds==3600, name
    assert row['cwd']==str(root), name
    for suffix in ('stdout','stderr'):
        assert (capture_dir/f'{row["number"]:02}.{suffix}.log').is_file()
for number in (17,19):
    cap=json.loads((capture_dir/f'before-{number:02}-capacity.json').read_text())
    assert cap['status']=='complete' and cap['protected_hashes_unchanged'] is True
    assert cap['previous_step']['exit_code']==0 and not cap['previous_step']['timed_out']
    commands=cap['commands']
    assert len(commands)==5
    for cmd in commands:
        assert cmd['exit_code']==0 and not cmd['timed_out'],cmd
    assert commands[3]['argv']==rows[13]['argv']
    assert commands[4]['argv']==rows[14]['argv']
    for name,expectedsha in cap['protected_hashes_before'].items():
        assert sha(Path(name))==expectedsha, name
for name in ['kg-storage-tests.json','domain-checkpoint-tests.json','ppr-algorithms-embeddings.json','vendor-vector-units.json','vendor-snapshot-units.json','vendor-wcc-units.json','standalone-critic-nonmodel-tests.json','root-adapters-library-tests.json','root-ledger-contract-tests.json','kg-storage-tests-after-lint.json','mcp-library-tests.json','embedding-roots-focused-tests.json','embedding-roots-layout-tests.json','embedding-roots-clippy-after-lint.json']:
    passed(name)
critic=passed('standalone-critic-nonmodel-tests.json')
assert critic['passed']==22 and critic['model_behavior_proved'] is False
assert critic['explicit_model_test_exclusions']==['gguf_critic::tests::gguf_determinism_two_runs_identical','gguf_critic::tests::gguf_verdict_path_and_discrimination']
assert load('feature-storage-clippy.json')['exit_code']==101
assert load('embedding-roots-clippy.json')['exit_code']==101
assert load('full-architecture-resource-interrupted.json')['exit_code']!=0
correction=load('original-patch-full-byte-proof-correction.json')
assert correction['old_aggregate_capture_not_complete']
assert correction['rust_raw_count']==247 and correction['raw_247_rust_original_files_equal_preupgrade_work_copy_hashes']
assert correction['complete_file_boundaries']==249
assert sha(audit/correction['complete_native_patch_backup'])==correction['complete_native_patch_sha256']
assert (audit/correction['complete_native_patch_backup']).stat().st_size==3323584
assert b'bytes dropped' not in (audit/correction['complete_native_patch_backup']).read_bytes()
work=next(item for item in load('user-temporary-scratch-cleanup.json')['removed'] if item['root'].endswith('/dirty-classification/work'))
assert len(work['file_hashes'])==247
for name,expectedsha in work['file_hashes'].items():
    assert sha(Path('/root/vendor-source/samyama-graph')/name)==expectedsha,name
for item in correction['untracked_eight_preserved_raw_copies']:
    assert sha(Path('/root/vendor-source/samyama-graph')/item['path'])==item['sha256']
    assert sha(audit/item['backup_relative_path'])==item['sha256']
patch=load('patch-reconstruction-actual-apply.json')
assert patch['exit_code']==0 and patch['all_recreated_files_equal_exact_candidate_bytes']
assert sha(root/'data/vendor_patches/samyama-m518-vector-wcc.patch')==patch['patch_sha256']=='23deec4f7d25c16379f4f0e4a5fc73534e22a8a8a538a3f6751561b6db3c3a9e'
for name,expectedsha in patch['reconstructed_candidate_sha256'].items():
    assert sha(Path('/root/vendor-source/samyama-graph-m518-17e55660')/name)==expectedsha,name
graph=load('after-content-repair-graph-checks.json')
assert graph['refresh_exit_code']==graph['identity_detect_exit_code']==0
assert graph['path_id_mismatch_count']==graph['changed_symbol_parity_bad_count']==0
assert graph['global_path_nodes']==107159 and graph['changed_count']==65
assert graph['detect_partial'] is False and graph['detect_truncated'] is False
assert graph['graph_global_coverage_proved'] is False
ledger=passed('root-ledger-contract-tests.json')
assert ledger['passed']==4 and ledger['lease_seconds']==30 and not ledger['lease_constant_changed']
assert not ledger['SIGSTOP_runtime_guard'] and ledger['no_production_store_opened']
closed=load('ledger-old-closed-original-hash.json')
original=Path(closed['original_path'])
hashes={str(p.relative_to(original)):{'size':p.stat().st_size,'sha256':sha(p)} for p in sorted(original.rglob('*')) if p.is_file()}
assert hashes==closed['tree']['files']
assert hashlib.sha256(json.dumps(hashes,sort_keys=True,separators=(',',':')).encode()).hexdigest()==closed['tree']['tree_sha256']
assert sha(original.parent/'old-expected.json')==closed['expected_sha256']
print(json.dumps({'verdict':'PASS','kind':'artifact-only; no runtime or store open','native_steps':len(rows),'supplemental_boundaries':2,'source_files':917,'original_files':249,'scoped_executions':878,'unique_tests_claimed':False,'general_bincode_migration_proved':False,'GGUF_inference':False,'MSRV_1_85_proved':False,'global_graph_coverage_proved':False}))
