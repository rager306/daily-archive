# M518 journey index repair — read-only review

## Verdict

**No material findings in the journey repair.** The change is at the concrete CLI composition boundary, not the shared embedding writer. It is safe to accept this narrowly scoped repair; it is not evidence that the whole vendor upgrade is production-compatible or that the architecture gate passed.

## Source and test review

- `crates/da-cli/src/load_journey.rs:489–512`: only the existing unstamped-Paper `None` branch declares an absent `Paper.embedding` index. Existence check and creation share one `store_write()` guard. Dimensions come from the injected embedder; cosine reuses the existing policy. The guard ends before the existing asynchronous add, whose success still precedes the SHA stamp. Existing equal-SHA and stale-embedding branches are unchanged.
- Existing indexes are not recreated, rebound, renamed, or requantized. Current vendor `manager.rs:91–123` confirms unconditional creation would replace vectors and clear the model binding; `:197–221` confirms a missing declaration is now an error. Current `index.rs:374–385` rejects dimension mismatch before mutation and preserves equal re-add/conflict semantics. No shared-writer or universal adapter policy change is part of this diff.
- `tests/load_journey_test.rs:327–424`: bare-store success and replay now prove a searchable Paper vector and count one, with injected dimensions and cosine, rather than relying only on a SHA stamp.
- `:465–558`: a distinct seeded Paper exercises the first-attach branch with an already populated named FP16 index. Both seed and new Paper remain searchable through replay; index Arc identity, dimensions, metric, FP16, model binding, name, and count two are checked.
- `:560–638`: incompatible dimensions reject the journey while retaining the original named L2/FP16 index, seed vector, binding, dimensions, and count one; the new Paper has no SHA stamp. These are state assertions, not relaxed error-string expectations.
- The inspected diff of both repaired files is addition-only: **no existing assertions or lines were removed**. Existing candidate-only/import-lock, cache, graph-idempotence, and SHA assertions remain. No constants were changed; the new declaration uses injected dimensions and the existing cosine policy.

## Verification binding and limits

Current SHA-256 values match all three supplied receipts exactly:

| Source | SHA-256 |
|---|---|
| `crates/da-cli/src/load_journey.rs` | `7e05b1a85750b69b2c0c575131872158d06902b681c4705373c4ea18bb627560` |
| `crates/da-cli/tests/load_journey_test.rs` | `0a63ccfdba2a7099b94a1df870f66448f3c8f5f8d9307d43652109e8b32c4913` |

`journey-index-focused-tests.json` records exit 0, **11 passing tests** (2 governed-process + 9 journey). `journey-index-pdf-layout-tests.json` records the same **11 passes** with `pdf-layout`. `journey-index-clippy.json` records exit 0 for both targets with `pdf-layout` and warnings denied. These are supplied execution results over hermetic process-local stores/fakes, not tests executed by this reviewer and not live production/inference proof.

The original architecture run remains **19 completed: 17 pass, 2 fail; step 20 resource-interrupted; 21–23 not run**. Focused receipts repair evidence for the two targets do not turn that incomplete full run into a gate pass.

## Upgrade acceptance beyond this repair

The earlier `journey-index-boundary-review.md` identifies source-confirmed bare-store legacy load/ingest embedding paths targeting **Paper or PaperRevision**, with no declaration at those composition boundaries. Current vendor semantics imply their first add returns a missing-index error when that embedding branch executes. Those runtime outcomes were **not executed in this review**; the journey receipts do not cover them.

**For whole-runtime vendor-upgrade acceptance, the legacy production paths need repair or an explicit acceptance-scope exclusion before claiming compatibility.** They are not reasons to reject this correct journey patch or edit the CRITICAL shared writer. A narrow acceptance can explicitly defer those paths with a tracked composition-boundary follow-up, but must say it accepts only the repaired journey, not all production ingestion.

Optional **Entity.embedding** is a separate known risk: without a declared index, its configured writer warns and does not count a successful vector write while extraction continues. That is not proof of process failure. It can be explicitly deferred if Entity vector readiness is outside acceptance; if it is in scope, provision and verify it before claiming that readiness. The diagnosed examples likewise remain predictions, not newly executed failures. No additional inventory was undertaken.

Scope: the two repaired files, supplied boundary diagnosis/receipts, current vendor manager/index semantics, and a read-only diff. No implementation edits, cargo/tests, store execution, graph refresh, cleanup, network, or inference were performed. The pre-edit daily graph was structural evidence only (journey MEDIUM; shared writer CRITICAL); no new graph-risk claim is made here.
